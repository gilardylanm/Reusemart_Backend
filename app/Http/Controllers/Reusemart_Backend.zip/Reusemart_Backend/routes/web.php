<?php

use App\Http\Controllers\ProdukController;
use App\Models\Request_Donasi;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrganisasiWebController;
use App\Http\Controllers\PegawaiWebController;
use App\Http\Controllers\jabatanWebController;
use App\Http\Controllers\PenitipWebController;
use App\Http\Controllers\PembeliWebController;
use App\Http\Controllers\RequestWebController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PegawaiController;
use App\Http\Controllers\DonasiController;
use App\Http\Controllers\MerchandiseWebController;
use App\Http\Controllers\PenitipanController;

Route::get('/test-session', function () {
    session(['test_key' => 'Coba Session']);
    return redirect('/check-session');
});

Route::get('/check-session', function () {
    return session('test_key', 'Session tidak ditemukan');
});


Route::get('/detailProduk', function () {
    return view('detailProduk');
});

Route::get('/laporanBulanan', [PegawaiWebController::class, 'laporanBulanan']);

Route::get('/laporanKomisi', [PegawaiWebController::class, 'laporanKomisi']);

Route::get('/viewLaporanKomisi', function () {
    $barangList=[];
    return view('laporanKomisi', compact('barangList'));
});

Route::get('/laporanGudang', [PenitipanController::class, 'laporanGudang']);

// Tampilkan form login
Route::get('/login', function () {
    return view('loginPage'); // Ganti 'login' dengan nama file blade kamu jika berbeda
})->name('login.form');

// Proses login
Route::post('/login', [AuthController::class, 'login'])->name('login');

// Logout
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/register', function () {
    return view('RegisterPembeli');
});

Route::get('/registerOrganisasi', function () {
    return view('RegisterOrganisasi');
});

Route::get('/organisasi', function () {
    $requestList = Request_Donasi::all(); // Ambil semua data dari tabel request_donasi
    return view('organisasi', ['requestList' => $requestList]);
})->name('organisasi');

Route::get('/halamanPembeli', function () {
    return view('halamanPembeli'); // Halaman utama untuk organisasi
})->name('halamanPembeli');

Route::get('/halamanPenitip', function () {
    return view('halamanPenitip'); // Halaman utama untuk organisasi
})->name('halamanPenitip');

// Menampilkan halaman daftar pembeli
Route::get('/pembeli', [PembeliWebController::class, 'index'])->name('pembeli.index');

// Menyimpan data pembeli dari form (POST)
Route::post('/pembeli', [PembeliWebController::class, 'store'])->name('pembeli.store');

//Route::get('/profilPembeli', [PembeliWebController::class, 'profil'])->name('profilPembeli');

Route::get('/rataratingpenitip', [PembeliWebController::class, 'ratarata'])->name('penitip.rata');

Route::get('/profilPenitip', function () {
    return redirect()->route('penitip.rata');
});

Route::get('/profilPembeli', function () {
    return view('ProfilPembeli');
});

use App\Http\Controllers\RequestController;
use App\Models\Penitipan;

Route::get('/organisasi', [RequestController::class, 'index'])->name('request.index');
Route::post('/requestdonasi', [RequestController::class, 'store'])->name('requestdonasi.store');
Route::put('/request/{id}', [RequestController::class, 'update'])->name('request.update');
Route::delete('/requestdonasiorg/{id}', [RequestController::class, 'destroy'])->name('requestdonasiorg.destroy');

// Route::resource('request', RequestController::class);
Route::get('request/export', [RequestController::class, 'export'])->name('request.export');


Route::get('/admin/adminForMerchandise', function () {
    return view('admin/adminForMerchandise');
});

Route::post('/register-organisasi', [OrganisasiWebController::class, 'register'])->name('organisasi.register');
Route::get('/admin/adminForOrganisasi', [OrganisasiWebController::class, 'index']);
Route::put('/admin/adminForOrganisasi/{id}', [OrganisasiWebController::class, 'update'])->name('organisasi.update');
Route::delete('/admin/adminForOrganisasi/{id}', [OrganisasiWebController::class, 'destroy'])->name('organisasi.destroy');
Route::get('/admin/adminForOrganisasi', [OrganisasiWebController::class, 'search']);

Route::post('/store-jabatan', [JabatanWebController::class, 'store'])->name('jabatan.store');
Route::get('/admin/adminForJabatan', [JabatanWebController::class, 'index']);
Route::put('/admin/adminForJabatan/{id}', [JabatanWebController::class, 'update'])->name('jabatan.update');
Route::delete('/admin/adminForJabatan/{id}', [JabatanWebController::class, 'destroy'])->name('jabatan.destroy');
Route::get('/admin/adminForJabatan', [JabatanWebController::class, 'search']);

Route::get('/admin/adminForPegawai', [PegawaiWebController::class, 'index']);
Route::get('/admin/adminForPegawai', [PegawaiController::class, 'create'])->name('pegawai.create');
Route::post('/admin/adminForPegawai', [PegawaiController::class, 'store'])->name('pegawai.store');
Route::put('/admin/adminForpegawai/{id}', [PegawaiController::class, 'update'])->name('pegawai.update');
Route::delete('/admin/adminForPegawai/{id}', [PegawaiWebController::class, 'destroy'])->name('pegawai.destroy');
Route::get('/admin/adminForPegawai', [PegawaiWebController::class, 'search']);

Route::get('/csPenitip', [PenitipWebController::class, 'index']);
Route::post('/store-penitip', [PenitipWebController::class, 'store'])->name('penitip.store');
Route::put('/csPenitip/{id}', [PenitipWebController::class, 'update'])->name('penitip.update');
Route::delete('/csPenitip/{id}', [PenitipWebController::class, 'destroy'])->name('penitip.destroy');
Route::get('/csPenitip', [PenitipWebController::class, 'search']);

Route::get('/merch', [MerchandiseWebController::class, 'index'])->name('penukaran.index');
Route::post('/ubah-tanggal-klaim', [MerchandiseWebController::class, 'ubahTanggalKlaim'])->name('ubah.tanggal.klaim');

Route::get('/historyPenitipan/{id}', [PenitipWebController::class, 'history'])->name('penitip.history');
Route::post('/historyPenitipan/{id}', [PenitipWebController::class, 'perpanjang'])->name('penitipan.perpanjang');

Route::get('/historyPembelian', [PembeliWebController::class, 'rating'])->name('historyPembelian');
Route::post('/rating/simpan', [PembeliWebController::class, 'simpanRating'])->name('rating.simpan');

Route::get('/profil.rating', [PembeliWebController::class, 'ratarata'])->name('profil.rating');



Route::get('/penitipan', [PenitipanController::class, 'index'])->name('penitipan.index');
Route::post('/penitipan/store', [PenitipanController::class, 'create'])->name('penitipan.store');
Route::post('/penitipan/{id}/edit', [PenitipanController::class, 'edit'])->name('penitipan.edit');
Route::delete('/penitipan/{id}/destroy', [PenitipanController::class, 'destroy'])->name('penitipan.destroy');
Route::get('/transaksiPenitipan/{id}', [PenitipanController::class, 'showTransaksi'])->name('penitipan.transaksi');

Route::post('/transaksiPenitipan/create', [PenitipanController::class, 'storeBarang'])->name('store.barang');
Route::put('/transaksiPenitipan/update/{id}', [PenitipanController::class, 'updateBarang'])->name('update.barang');
Route::delete('/transaksiPenitipan/delete/{id}', [PenitipanController::class, 'deleteBarang'])->name('delete.barang');
Route::get('/notaBarang/{id}', [PenitipanController::class, 'cetakNota'])->name('cetak.nota');



Route::get('/admin/adminForPegawai', [PegawaiWebController::class, 'index']);

Route::get('/requestDonasi', [DonasiController::class, 'index'])->name('donasi. index');
Route::get('/requestDonasi/{id}', [DonasiController::class, 'show'])->name('donasi.show');






// Update
//Route::post('/organisasi/update/{id}', [OrganisasiWebController::class, 'update'])->name('organisasi.update');

// Search
Route::get('/organisasi/search', [OrganisasiWebController::class, 'search'])->name('organisasi.search');

// Delete
Route::delete('/organisasi/delete/{id}', [OrganisasiWebController::class, 'destroy'])->name('organisasi.destroy');

Route::get('/admin/adminForReset', function () {
    return view('admin/adminForReset');
});

Route::get('/request', [RequestWebController::class, 'index'])->name('request.index');

// Simpan request donasi baru
Route::post('/request', [RequestWebController::class, 'store'])->name('request.store');

// Update request donasi
Route::put('/request/{id}', [RequestWebController::class, 'update'])->name('request.update');

// Hapus request donasi
// Route::delete('/request/{id}', [RequestWebController::class, 'destroy'])->name('request.destroy');
