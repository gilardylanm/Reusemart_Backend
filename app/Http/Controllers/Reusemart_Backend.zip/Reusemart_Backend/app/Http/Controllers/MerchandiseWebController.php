<?php

namespace App\Http\Controllers;

use App\Models\PenukaranPoin;
use Illuminate\Http\Request;

class MerchandiseWebController extends Controller
{
    public function index()
    {
        $merchList = PenukaranPoin::all();
        return view('CSForMerch', compact('merchList'));
    }

    public function ubahTanggalKlaim(Request $request)
    {
        // Validasi input
        $request->validate([
            'id' => 'required|integer|exists:penukaranpoin,ID_PENUKARAN', // sesuaikan nama tabel & kolom
            'tanggal' => 'required|date',
        ]);

        // Cari data berdasarkan ID
        $penukaran = PenukaranPoin::find($request->id);
        $penukaran->TANGGAL_KLAIM = $request->tanggal;
        $penukaran->save();

        return redirect()->back()->with('success', 'Tanggal klaim berhasil diubah.');
    }

}
