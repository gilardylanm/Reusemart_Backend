<?php

namespace App\Http\Controllers;

use App\Models\Organisasi;
use Illuminate\Http\Request as HttpRequest;
use App\Models\Request_Donasi; // Sesuaikan dengan nama model Anda
use App\Models\Request;
use Illuminate\Support\Facades\Auth;

class RequestController extends Controller
{
    public function index()
    {
        $requestList = Request::all();
        return view('organisasi', compact('requestList'));
    }
public function store(HttpRequest $request)
{
    $validated = $request->validate([
        'NAMA_BARANG' => 'required|string|max:255',
        'DESKRIPSI_REQUEST' => 'required|string'
    ]);

    Request_Donasi::create([
        'ID_ORGANISASI'=>session('user_id'),
        'NAMA_BARANG' => $validated['NAMA_BARANG'],
        'DESKRIPSI_REQUEST' => $validated['DESKRIPSI_REQUEST'],
        'TANGGAL_REQUEST' => now(),
        'STATUS_REQUEST' => 'Menunggu'
        // Tidak menyertakan ID_ORGANISASI
    ]);

    
    $organisasi = Organisasi::where('ID_ORGANISASI', session('user_id'))->first();
    $requestList = Request_Donasi::where('ID_ORGANISASI', $organisasi->ID_ORGANISASI)->get();
    
    // Kirim ke view 'organisasi'
    return view('organisasi', [
        'organisasi' => $organisasi,
        'requestList' => $requestList,
    ]);
    // return redirect()->route('organisasi')->with('success', 'Request Donasi berhasil ditambahkan.');
}


public function update(Request $request, $id)
{
    $validated = $request->validate([
        'NAMA_BARANG' => 'required|string|max:255',
        'DESKRIPSI_REQUEST' => 'required|string',
        'STATUS_REQUEST' => 'required|in:Menunggu,Diterima,Ditolak'
    ]);

    $donasiRequest = Request_Donasi::findOrFail($id);
    
    // Update hanya field yang diubah (tanpa ID_ORGANISASI)
    $donasiRequest->update($validated);

    return redirect()->back()->with('success', 'Request berhasil diperbarui');
}
    public function destroy($id)
    {
        $requestDonasi = Request_Donasi::findOrFail($id);
        $requestDonasi->delete();

        return redirect()->back()->with('success', 'Data Request berhasil dihapus.');
    }
}
