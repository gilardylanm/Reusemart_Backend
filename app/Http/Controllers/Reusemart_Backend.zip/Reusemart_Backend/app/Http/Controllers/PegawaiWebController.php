<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pegawai;
use App\Models\Jabatan;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\JabatanWebController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Exception;

class PegawaiWebController extends Controller
{
    public function index()
    {
        $pegawaiList = Pegawai::all();
        $jabatanList = Jabatan::all();
        return view('admin.adminForPegawai', compact( 'pegawaiList', 'jabatanList'));
    }

    public function store(Request $request)
    {

        $request->validate([
            'NAMA_PEGAWAI' => 'required',
            'EMAIL_PEGAWAI' => 'required|email|unique:pegawai,EMAIL_PEGAWAI',
            'NOTELP_PEGAWAI' => 'required',
            'ID_JABATAN' => 'required',
            'TGL_LAHIR' => 'required|date',
            'PASSWORD_PEGAWAI' => 'required|min:6',
        ]);

        Pegawai::create([
            'NAMA_PEGAWAI' => $request->NAMA_PEGAWAI,
            'EMAIL_PEGAWAI' => $request->EMAIL_PEGAWAI,
            'NOTELP_PEGAWAI' => $request->NOTELP_PEGAWAI,
            'ID_JABATAN' => $request->ID_JABATAN,
            'TGL_LAHIR' => $request->TGL_LAHIR,
            'PASSWORD_PEGAWAI' => Hash::make($request->PASSWORD_ORGANISASI),
        ]);

        return redirect()->back()->with('success', 'Data pegawai berhasil dibuat.');
    }

public function update(Request $request, $id)
{
    $pegawaiList = Pegawai::findOrFail($id);

    $pegawaiList->NAMA_PEGAWAI = $request->NAMA_PEGAWAI;
    $pegawaiList->EMAIL_PEGAWAI = $request->EMAIL_PEGAWAI;
    $pegawaiList->NOTELP_PEGAWAI = $request->NOTELP_PEGAWAI;
    $pegawaiList->TGL_LAHIR = $request->TGL_LAHIR;

    // Jika password bisa dikosongkan saat edit
    if ($request->filled('PASSWORD_PEGAWAI')) {
        $pegawaiList->PASSWORD_PEGAWAI = Hash::make($request->PASSWORD_PEGAWAI);
    }

    $pegawaiList->save();

    return redirect()->route('adminForPegawai')->with('success', 'Data pegawai berhasil diupdate.');
}



    // Menghapus data pegawai
    public function destroy($id)
    {
        $pegawai = Pegawai::findOrFail($id);
        $pegawai->delete();

        return redirect()->back()->with('success', 'Data pegawai berhasil dihapus.');
    }

    public function search(Request $request)
    {
        $search = $request->input('search');

        $pegawaiList = Pegawai::when($search, function ($query, $search) {
            return $query->where('NAMA_PEGAWAI', 'like', "%$search%");
        })->get();

        return view('admin.adminForPegawai', compact('pegawaiList', 'search'));
    }
public function laporanBulanan()
{
    $currentYear = now()->year;

    $pembelian = DB::table('pembelian')
        ->join('detailpembelian', 'pembelian.ID_PEMBELIAN', '=', 'detailpembelian.ID_PEMBELIAN')
        ->join('barang', 'detailpembelian.ID_BARANG', '=', 'barang.ID_BARANG')
        ->whereYear('pembelian.TANGGAL_PEMBELIAN', $currentYear)
        ->select(
            'pembelian.TANGGAL_PEMBELIAN',
            'pembelian.JUMLAH_TERJUAL',
            'barang.HARGA_BARANG'
        )
        ->get();

    // Daftar bulan dalam bahasa Indonesia
    $bulanIndo = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    // Inisialisasi data per bulan
    $dataPenjualan = [];
    foreach ($bulanIndo as $monthNum => $namaBulan) {
        $dataPenjualan[$namaBulan] = [
            'JUMLAH_TERJUAL' => 0,
            'penjualan_kotor' => 0
        ];
    }

    // Proses data pembelian
    foreach ($pembelian as $item) {
        $tanggal = Carbon::parse($item->TANGGAL_PEMBELIAN);
        $monthNum = $tanggal->month;
        $namaBulan = $bulanIndo[$monthNum];

        $jumlah = $item->JUMLAH_TERJUAL ?? 0;
        $harga = $item->HARGA_BARANG ?? 0;
        $subtotal = $jumlah * $harga;

        $dataPenjualan[$namaBulan]['JUMLAH_TERJUAL'] += $jumlah;
        $dataPenjualan[$namaBulan]['penjualan_kotor'] += $subtotal;
    }

    // Hitung total keseluruhan
    $totalBarang = array_sum(array_column($dataPenjualan, 'JUMLAH_TERJUAL'));
    $totalPenjualan = array_sum(array_column($dataPenjualan, 'penjualan_kotor'));

    // Siapkan array numerik penjualan_kotor per bulan untuk Chart.js
    $penjualanPerBulan = [];
    foreach ($bulanIndo as $monthNum => $namaBulan) {
        $penjualanPerBulan[] = $dataPenjualan[$namaBulan]['penjualan_kotor'] ?? 0;
    }

    return view('laporanBulanan', [
        'dataPenjualan' => $dataPenjualan,
        'tahun' => $currentYear,
        'totalBarang' => $totalBarang,
        'totalPenjualan' => $totalPenjualan,
        'tanggalCetak' => Carbon::now()->translatedFormat('j F Y'),
        'bulanIndo' => $bulanIndo,
        'penjualanData' => $penjualanPerBulan,
    ]);
}

public function laporanKomisi(Request $request)
{
    // Ambil bulan dan tahun dari request jika ada
    $credentials = $request->validate([
        'bulan' => 'required',
        'tahun' => 'required'
    ]);

    $bulan = $credentials['bulan'];
    $tahun = $credentials['tahun'];

    $barangList = DB::table('penitipan')
        ->join('penitip', 'penitipan.ID_PENITIP', '=', 'penitip.ID_PENITIP')
        ->join('barang', 'barang.ID_PENITIPAN', '=', 'penitipan.ID_PENITIPAN')
        ->join('detailpembelian', 'detailpembelian.ID_BARANG', '=', 'barang.ID_BARANG')
        ->join('pembelian', 'pembelian.ID_PEMBELIAN', '=', 'detailpembelian.ID_PEMBELIAN')
        ->leftJoin('hunter', 'penitipan.ID_HUNTER', '=', 'hunter.ID_HUNTER') // Ubah menjadi leftJoin
        ->leftJoin('komisi', function($join) {
            $join->on('komisi.ID_PEMBELIAN', '=', 'pembelian.ID_PEMBELIAN')
                 ->on('komisi.ID_PENITIP', '=', 'penitip.ID_PENITIP');
        })
        ->whereMonth('pembelian.TANGGAL_LUNAS', $bulan)
        ->whereYear('pembelian.TANGGAL_LUNAS', $tahun)
        ->select(
            'penitipan.ID_PENITIPAN as NO_NOTA',
            'penitipan.TANGGAL_PENITIPAN',
            'penitipan.TANGGAL_BERAKHIR',
            'penitip.NAMA_PENITIP',
            'penitip.ALAMAT_PENITIP',
            'barang.NAMA_BARANG',
            'barang.HARGA_BARANG',
            'barang.GARANSI',
            'barang.BERAT',
            'hunter.ID_HUNTER',
            'hunter.NAMA_HUNTER',
            'pembelian.TANGGAL_PEMBELIAN',
            'pembelian.TANGGAL_LUNAS',
            'komisi.ID_KOMISI',
            'komisi.ID_PEGAWAI',
            'komisi.JUMLAH_KOMISI',
            'komisi.PERSENTASE_KOMISI',
            'komisi.TANGGAL_KOMISI'
        )
        ->get();

    foreach ($barangList as $barang) {
        if ($barang->ID_KOMISI) {
            $barang->KOMISI_HUNTER = 0;
            $barang->KOMISI_REUSE = $barang->JUMLAH_KOMISI;
            $barang->BONUS_PENITIP = 0;
            continue;
        }

        $harga = $barang->HARGA_BARANG;
        $tanggalPembelian = \Carbon\Carbon::parse($barang->TANGGAL_PEMBELIAN);
        $tanggalLunas = \Carbon\Carbon::parse($barang->TANGGAL_LUNAS);
        $tanggalPenitipan = \Carbon\Carbon::parse($barang->TANGGAL_PENITIPAN);
        $tanggalBerakhir = \Carbon\Carbon::parse($barang->TANGGAL_BERAKHIR);

        $lamaLunas = $tanggalPenitipan->diffInDays($tanggalLunas);

        // Inisialisasi nilai komisi
        $komisiReuse = 0;
        $komisiHunter = 0; // Default 0 jika hunter null
        $bonusPenitip = 0;
        $persentase = 20; // Default 20%

        if ($lamaLunas < 7) {
            $persentase = 20;
            $komisiReuse = $harga * 0.20;
            $komisiHunter = $barang->ID_HUNTER ? $komisiReuse * 0.05 : 0;
            $bonusPenitip = $komisiReuse * 0.10;
        } elseif ($lamaLunas > 30) {
            $persentase = 30;
            $komisiReuse = $harga * 0.30;
            $komisiHunter = $barang->ID_HUNTER ? $komisiReuse * 0.05 : 0;
        } else {
            $persentase = 20;
            $komisiReuse = $harga * 0.20;
            $komisiHunter = $barang->ID_HUNTER ? $komisiReuse * 0.05 : 0;
        }

        // Hitung komisi Reuse setelah dipotong komisi lain
        $komisiReuseSisa = $komisiReuse - $komisiHunter - $bonusPenitip;
        $barang->KOMISI_REUSE = round($komisiReuseSisa);
        $barang->KOMISI_HUNTER = round($komisiHunter);
        $barang->BONUS_PENITIP = round($bonusPenitip);
        $barang->PERSENTASE_KOMISI = $persentase;
    }

    return view('laporanKomisi', compact('barangList', 'bulan', 'tahun'));
}

}
