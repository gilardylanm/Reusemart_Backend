<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pegawai;
use App\Models\Jabatan;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Exception;

class PegawaiController extends Controller
{
    
    public function index()
    {
        // Menampilkan semua penitip
        $pegawais = Pegawai::all();
        return view('adminForPegawai', compact('pegawais'));
    }
    public function create()
    {
        $jabatans = Jabatan::all();  // Ambil semua data jabatan
        return view('admin.adminForPegawai', compact('jabatans'));
    }


   public function store(Request $request)
{
    try {
        $request->validate([
            'NAMA_PEGAWAI' => 'required|string',
            'EMAIL_PEGAWAI' => 'required|email',
            'NOTELP_PEGAWAI' => 'required|string',
            'ID_JABATAN' => 'required|exists:jabatan,ID_JABATAN',
            'TGL_LAHIR' => 'required|date',
            'PASSWORD_PEGAWAI' => 'required|string|min:6',
        ]);

        $pegawai = Pegawai::create([
            'NAMA_PEGAWAI' => $request->NAMA_PEGAWAI,
            'EMAIL_PEGAWAI' => $request->EMAIL_PEGAWAI,
            'NOTELP_PEGAWAI' => $request->NOTELP_PEGAWAI,
            'ID_JABATAN' => $request->ID_JABATAN,
            'TGL_LAHIR' => $request->TGL_LAHIR,
            'PASSWORD_PEGAWAI' => Hash::make($request->PASSWORD_PEGAWAI),
        ]);

        $pegawaiList = Pegawai::all();
         $jabatans = Jabatan::all(); 
        return view('admin.adminForPegawai', ['pegawaiList' => $pegawaiList, 'jabatanList' => $jabatans]);
    
    } catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'status' => false,
            'message' => 'Validation failed',
            'errors' => $e->errors()
        ], 422);

    } catch (Exception $e) {
        return response()->json([
            'status' => false,
            'message' => 'Something went wrong',
            'error' => $e->getMessage()
        ], 500);
    }
}

    public function update(Request $request, $id)
{
    $request->validate([
        'NAMA_PEGAWAI' => 'required|string|max:255',
        'EMAIL_PEGAWAI' => 'required|email',
        'NOTELP_PEGAWAI' => 'required|string|max:15',
        'TGL_LAHIR' => 'required|date',
    ]);

    $pegawai = Pegawai::findOrFail($id);
    $pegawai->NAMA_PEGAWAI = $request->NAMA_PEGAWAI;
    $pegawai->EMAIL_PEGAWAI = $request->EMAIL_PEGAWAI;
    $pegawai->NOTELP_PEGAWAI = $request->NOTELP_PEGAWAI;
    $pegawai->TGL_LAHIR = $request->TGL_LAHIR;
    $pegawai->save();

    return redirect()->back()->with('success', 'Data pegawai berhasil diperbarui.');
}



}
