<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Donasi;

class DonasiController extends Controller
{
public function index()
{
    $donasiList = Donasi::all(); // atau pakai paginate(), dsb

    return view('donasi.index', compact('donasiList'));
}

    public function show($id)
    {
        $donasi = Donasi::findOrFail($id);
        return view('requestDonasi', compact('donasi'));
    }
}
