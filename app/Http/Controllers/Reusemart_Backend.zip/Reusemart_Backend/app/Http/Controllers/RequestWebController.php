<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Request_Donasi;
use App\Models\Organisasi;

class RequestWebController extends Controller
{
    public function index()
    {
        $requests = Request_Donasi::all();
        return view('organisasi', compact('requests'));
    }

    // Menyimpan Request Donasi baru ke dalam database
    public function store(Request $request)
    {
        $validated = $request->validate([
            'ID_ORGANISASI' => 'required|exists:organisasi,ID_ORGANISASI',
            'DESKRIPSI_REQUEST' => 'required|string|max:255',
            'NAMA_BARANG' => 'required|string|max:100', // tambahkan validasi nama barang jika perlu
        ]);

        // Tambahkan nilai otomatis
        $validated['TANGGAL_REQUEST'] = now(); // waktu saat ini
        $validated['STATUS_REQUEST'] = 'menunggu';

        Request_Donasi::create($validated);

        return redirect()->route('organisasi')->with('success', 'Request Donasi berhasil ditambahkan.');
    }

    // Memperbarui Request Donasi di database
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'DESKRIPSI_REQUEST' => 'required|string|max:255',
            'NAMA_BARANG' => 'required|string|max:100', // jika digunakan
        ]);

        $requestDonasi = Request_Donasi::findOrFail($id);

        $requestDonasi->update([
            'ID_ORGANISASI' => session('user_id'), // asumsikan login sebagai organisasi
            'DESKRIPSI_REQUEST' => $validated['DESKRIPSI_REQUEST'],
            'NAMA_BARANG' => $validated['NAMA_BARANG'], // jika ada
            'TANGGAL_REQUEST' => now(),
            'STATUS_REQUEST' => 'menunggu',
        ]);

        return redirect()->back()->with('success', 'Data Request berhasil diupdate.');
    }

    // Menghapus Request Donasi
    public function destroy($id)
    {
        $requestDonasi = Request_Donasi::findOrFail($id);
        $requestDonasi->delete();

        return redirect()->back()->with('success', 'Data Request berhasil dihapus.');
    }   
}
