<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pembeli;
use App\Models\Penitipan;
use App\Models\Penitip;
use App\Models\Barang;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;


class PenitipanController extends Controller
{
public function index()
{
    $penitipanList = Penitipan::all(); // Gantilah dengan query yang sesuai
    return view('penitipanBarang', compact('penitipanList'));
}

public function create(Request $request)
{
    // Validasi input, tanpa ID_PENITIPAN karena auto-increment
    $validated = $request->validate([
        'ID_PENITIP' => 'required|string|exists:penitip,ID_PENITIP',
        'ID_PEGAWAI' => 'required|string|exists:pegawai,ID_PEGAWAI',
        'TANGGAL_PENITIPAN' => 'required|date',
        'TANGGAL_BERAKHIR' => 'nullable|date',
        'STATUS_PERPANJANGAN' => 'nullable|integer', // pastikan tipe sesuai DB
        'BATAS_AMBIL' => 'nullable|date',
        'STATUS_AMBIL_KEMBALI' => 'nullable|integer', // pastikan tipe sesuai DB
    ]);

    // Simpan data, biarkan ID_PENITIPAN auto-increment dari DB
    Penitipan::create($validated);

    return redirect()->route('penitipan.index')->with('success', 'Data berhasil ditambahkan.');
}



    public function edit(Request $request, $id)
    {
        $penitipan = Penitipan::findOrFail($id);
        $penitipan->update([
            'TANGGAL_PENITIPAN'=>$request['TANGGAL_PENITIPAN']
        ]);
        $penitip=Penitip::find($penitipan->ID_PENITIP);
        $penitip->update([
            'NAMA_PENITIP'=>$request['NAMA_PENITIP'],
            'EMAIL_PENITIP'=>$request['EMAIL_PENITIP']
        ]);
        return redirect()->route('penitipan.index')->with('success', 'Data berhasil diperbarui.');
    }

        



        // Hapus data penitipan
    public function destroy($id)
    {
        $penitipan = Penitipan::findOrFail($id);
        $penitipan->delete();

        return redirect()->route('penitipan.index')->with('success', 'Data berhasil dihapus.');
    }

        public function fetchPenitipanByPenitipId($ID_PENITIP)
        {
            try {
                $today = Carbon::now()->toDateString();

                // Update STATUS_PERPANJANGAN jika tanggal_akhir sudah lewat
                Penitipan::whereIn('STATUS_PERPANJANGAN', ['Tersedia', 'Belum Diambil'])
                    ->whereDate('TANGGAL_AKHIR', '<', $today)
                    ->update(['STATUS_PERPANJANGAN' => 'Belum Diambil']);

                // Ambil data penitipan + penitip berdasarkan id_penitip
                $data = DB::table('penitipan')
                    ->join('penitip', 'penitipan.ID_PENITIP', '=', 'penitip.ID_PENITIP')
                    ->where('penitipan.ID_PENITIP', $ID_PENITIP)
                    ->select(
                        'penitipan.ID_PENITIPAN',
                        'penitipan.TANGGAL_PENITIPAN',
                        'penitipan.TANGGAL_AKHIR',
                        'penitipan.STATUS_PERPANJANGAN',
                        'penitipan.DESKRIPSI',
                        'penitip.NAMA_PENITIP',
                        'penitip.EMAIL_PENITIP'
                    )
                    ->get();

                return response()->json([
                    'message' => 'Data retrieved successfully',
                    'data' => $data,
                ]);
            } catch (Exception $e) {
                return response()->json([
                    'message' => 'Failed to retrieve data',
                    'error' => $e->getMessage(),
                ], 500);
            }
        }

            public function fetchBarangToPenitip()
            {
                try {
                    $today = Carbon::now()->toDateString();

                    // Update STATUS_PERPANJANGAN jika tanggal_akhir sudah lewat
                    DB::table('penitipan')
                        ->whereIn('STATUS_PERPANJANGAN', ['Tersedia', 'Belum Diambil'])
                        ->whereDate('TANGGAL_AKHIR', '<', $today)
                        ->update(['STATUS_PERPANJANGAN' => 'Belum Diambil']);

                    // Ambil data dari barang → penitipan → penitip
                    $data = DB::table('barang')
                        ->leftJoin('penitipan', 'barang.ID_PENITIPAN', '=', 'penitipan.ID_PENITIPAN')
                        ->join('penitip', 'penitipan.ID_PENITIP', '=', 'penitip.ID_PENITIP')
                        ->select(
                            'barang.ID_BARANG',
                            'barang.NAMA_BARANG',
                            'barang.HARGA_BARANG',
                            'penitipan.ID_PENITIPAN',
                            'penitipan.TANGGAL_PENITIPAN',
                            'penitipan.TANGGAL_BERAKHIR',
                            'penitipan.STATUS_PERPANJANGAN',
                            'barang.DESKRIPSI_BARANG',
                            'penitip.ID_PENITIP',
                            'penitip.NAMA_PENITIP',
                            'penitip.EMAIL_PENITIP'
                        )
                        ->get();

                    return response()->json([
                        'message' => 'Data barang ke penitipan dan penitip berhasil diambil',
                        'data' => $data,
                    ]);
                } catch (Exception $e) {
                    return response()->json([
                        'message' => 'Gagal mengambil data',
                        'error' => $e->getMessage(),
                    ], 500);
                }
            }


public function showTransaksi($id)
{
        // Ambil data barang, penitipan, dan penitip berdasarkan ID_PENITIPAN = $id
        $data = DB::table('penitipan')
            ->join('barang', 'barang.ID_PENITIPAN', '=', 'penitipan.ID_PENITIPAN')
            ->join('penitip', 'penitipan.ID_PENITIP', '=', 'penitip.ID_PENITIP')
            ->where('penitipan.ID_PENITIPAN', $id)
            ->distinct()
            ->select(
                'barang.ID_BARANG',
                'barang.NAMA_BARANG',
                'barang.HARGA_BARANG',
                'penitipan.ID_PENITIPAN',
                'penitipan.TANGGAL_PENITIPAN',
                'penitipan.TANGGAL_BERAKHIR',
                'penitipan.STATUS_PERPANJANGAN',
                'barang.DESKRIPSI_BARANG',
                'penitip.ID_PENITIP',
                'penitip.NAMA_PENITIP',
                'penitip.EMAIL_PENITIP'
            )
            ->get();

        return view('transaksiPenitipan', [
            'barangList' => $data,
            'idpenitipan' =>$id,    
        ]);
    }

public function storeBarang(Request $request)
{
    $validated = $request->validate([
        'NAMA_BARANG' => 'required|string|max:255',
        'HARGA_BARANG' => 'required|numeric|min:0',
        'DESKRIPSI_BARANG' => 'nullable|string',
        'GARANSI' => 'nullable|date', // validasi sebagai tanggal
        'BERAT' => 'nullable|numeric',
        'KATEGORI_BARANG' => 'nullable|string',
        'STATUS_BARANG' => 'nullable|string',
        'STATUS_PERPANJANGAN' => 'required|in:0,1',
        'ID_PENITIPAN' => 'required|exists:penitipan,ID_PENITIPAN',
    ]);

    try {
        // Simpan barang ke DB via model
        Barang::create([
            'ID_PENITIPAN' => $request['ID_PENITIPAN'],
            'NAMA_BARANG' => $request['NAMA_BARANG'],
            'HARGA_BARANG' => $request['HARGA_BARANG'],
            'DESKRIPSI_BARANG' => $request['DESKRIPSI_BARANG'],
            'GARANSI' => $request['GARANSI'],
            'BERAT' => $request['BERAT'],
            'KATEGORI_BARANG' => $request['KATEGORI_BARANG'],
            'STATUS_BARANG' => $request['STATUS_BARANG'],
        ]);

        // Update status perpanjangan penitipan
        DB::table('penitipan')
            ->where('ID_PENITIPAN', $request['ID_PENITIPAN'])
            ->update(['STATUS_PERPANJANGAN' => $request['STATUS_PERPANJANGAN']]);

        return redirect()->back()->with('success', 'Barang berhasil ditambahkan.');
    } catch (\Exception $e) {
        return redirect()->back()->with('error', 'Gagal menambahkan barang: ' . $e->getMessage());
    }
}



public function updateBarang(Request $request, $id)
{
    try {
        // Validasi input
        $validated = $request->validate([
            'NAMA_BARANG' => 'required|string|max:255',
            'HARGA_BARANG' => 'required|numeric|min:0',
            'STATUS_PERPANJANGAN' => 'required', // pastikan ini integer 0 atau 1
        ]);

        // Update tabel barang
        DB::table('barang')
            ->where('ID_BARANG', $id)
            ->update([
                'NAMA_BARANG' => $validated['NAMA_BARANG'],
                'HARGA_BARANG' => $validated['HARGA_BARANG'],
            ]);

        // Ambil ID_PENITIPAN dari barang
        $barang = DB::table('barang')->where('ID_BARANG', $id)->first();

        if ($barang) {
            // Update tabel penitipan pakai ID_PENITIPAN
            DB::table('penitipan')
                ->where('ID_PENITIPAN', $barang->ID_PENITIPAN) 
                ->update([
                    'STATUS_PERPANJANGAN' => $validated['STATUS_PERPANJANGAN'],
                ]);

        }

        return redirect()->back()->with('success', 'Data barang berhasil diperbarui.');
    } catch (\Exception $e) {
        return redirect()->back()->with('error', 'Gagal memperbarui data: ' . $e->getMessage());
    }
}

public function deleteBarang($id)
{
    // Debug 1: Log ID yang diterima
    Log::info("Attempting to delete barang with ID: {$id}");

    try {
        // Debug 2: Cek tipe data ID
        Log::info("ID Type: " . gettype($id));
        
        // Convert to integer jika perlu
        $id = (int)$id;
        
        // Debug 3: Cek data sebelum delete
        $barang = Barang::with('penitipan')->find($id);
        Log::info("Barang Data: " . json_encode($barang));

        if (!$barang) {
            Log::warning("Barang not found with ID: {$id}");
            return redirect()->back()->with('error', 'Barang tidak ditemukan!');
        }

        // Debug 4: Cek relasi penitipan
        if ($barang->penitipan) {
            Log::info("Related Penitipan: " . json_encode($barang->penitipan));
        }

        DB::beginTransaction();

        // Debug 5: Simpan ID penitipan sebelum delete
        $idPenitipan = $barang->ID_PENITIPAN;
        Log::info("ID_PENITIPAN: {$idPenitipan}");

        // Eksekusi delete
        $deleteResult = $barang->delete();
        Log::info("Delete Result: " . ($deleteResult ? 'true' : 'false'));

        // Update status penitipan jika perlu
        if ($deleteResult && $barang->penitipan) {
            $updateResult = DB::table('penitipan')
                ->where('ID_PENITIPAN', $idPenitipan)
                ->update(['STATUS_PERPANJANGAN' => 0]);
            Log::info("Update Penitipan Result: {$updateResult}");
        }

        DB::commit();

        // Debug 6: Verifikasi penghapusan
        $existsAfterDelete = Barang::where('ID_BARANG', $id)->exists();
        Log::info("Exists After Delete: " . ($existsAfterDelete ? 'true' : 'false'));

        if (!$existsAfterDelete) {
            return redirect()->back()
                   ->with('success', 'Barang berhasil dihapus!')
                   ->with('debug', 'Data benar-benar terhapus dari database');
        }

        return redirect()->back()
               ->with('warning', 'Barang terhapus tetapi verifikasi gagal!');

    } catch (\Exception $e) {
        DB::rollBack();
        Log::error("Delete Error: " . $e->getMessage());
        Log::error("Stack Trace: " . $e->getTraceAsString());
        
        return redirect()->back()
               ->with('error', 'Gagal menghapus: ' . $e->getMessage())
               ->with('debug_error', $e->getTraceAsString());
    }
}

public function cetakNota($id)
{
    $barangList = DB::table('penitipan')
        ->join('barang', 'barang.ID_PENITIPAN', '=', 'penitipan.ID_PENITIPAN')
        ->join('penitip', 'penitipan.ID_PENITIP', '=', 'penitip.ID_PENITIP')
        ->where('penitipan.ID_PENITIPAN', $id)
        ->select(
            'penitipan.ID_PENITIPAN as NO_NOTA',
            'penitipan.TANGGAL_PENITIPAN',
            'penitipan.TANGGAL_BERAKHIR',
            'penitipan.ID_PENITIP',
            'penitip.NAMA_PENITIP',
            'penitip.ALAMAT_PENITIP',
            'barang.NAMA_BARANG',
            'barang.HARGA_BARANG',
            'barang.GARANSI',
            'barang.BERAT'
        )
        ->get();

    if ($barangList->isEmpty()) {
        abort(404, 'Data tidak ditemukan');
    }

    // Jalankan query dengan ->first()
    $kurir = DB::table('pegawai')
        ->where('ID_JABATAN', 4)
        ->first();

    $gudang = DB::table('pegawai')
        ->where('ID_JABATAN', 2)
        ->first();

    // Sisipkan nama pegawai ke objek barangList
    $barangList[0]->NAMA_KURIR = $kurir ? $kurir->NAMA_PEGAWAI : null;
    $barangList[0]->NAMA_PEGAWAI_GUDANG = $gudang ? $gudang->NAMA_PEGAWAI : null;

    return view('notaBarang', compact('barangList'));
}

public function laporanGudang()
{
    $stokGudang = DB::table('penitipan')
        ->join('barang', 'barang.ID_PENITIPAN', '=', 'penitipan.ID_PENITIPAN')
        ->join('penitip', 'penitipan.ID_PENITIP', '=', 'penitip.ID_PENITIP')
        ->join('hunter', 'penitipan.ID_HUNTER', '=', 'hunter.ID_HUNTER')
        ->whereDate('penitipan.TANGGAL_PENITIPAN', Carbon::today())
        ->select(
            'barang.ID_BARANG',
            'barang.NAMA_BARANG',
            'penitip.ID_PENITIP',
            'penitip.NAMA_PENITIP',
            'penitipan.TANGGAL_PENITIPAN',
            'penitipan.STATUS_PERPANJANGAN',
            'hunter.ID_HUNTER',
            'hunter.NAMA_HUNTER',
            'barang.HARGA_BARANG'
        )
        ->get();
    return view('laporanGudang', compact('stokGudang'));
}


}
