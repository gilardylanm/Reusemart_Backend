<?php

namespace App\Http\Controllers;

use App\Models\Penitip;
use App\Models\Penitipan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class PenitipWebController extends Controller
{
    public function index()
    {
        // Menampilkan semua penitip
        $penitips = Penitip::all();
        return view('CSForPenitip', compact('penitips'));
    }

    public function store(Request $request)
    {
        // Validasi input
        $validator = Validator::make($request->all(), [
            'NAMA_PENITIP' => 'required|string|max:255',
            'EMAIL_PENITIP' => 'required|email|max:255|unique:penitip',
            'ALAMAT_PENITIP' => 'required|string|max:255',
            'NIK' => 'required|string|max:16',
            'SCAN_KTP' => 'required|image|mimes:jpg,jpeg,png,gif|max:2048',
            'PASSWORD_PENITIP' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // Menyimpan file jika ada
        $scanKTPPath = null;
        if ($request->hasFile('SCAN_KTP')) {
            $scanKTPPath = $request->file('SCAN_KTP')->store('ktp_images', 'public');
        }

        // Menyimpan penitip baru
        Penitip::create([
            'NAMA_PENITIP' => $request->NAMA_PENITIP,
            'EMAIL_PENITIP' => $request->EMAIL_PENITIP,
            'ALAMAT_PENITIP' => $request->ALAMAT_PENITIP,
            'NIK' => $request->NIK,
            'SCAN_KTP' => $scanKTPPath,
            'PASSWORD_PENITIP' => bcrypt($request->PASSWORD_PENITIP),
            'SALDO_PENITIP' => 0,
        ]);

        return redirect()->back()->with('success', 'Data penitip berhasil dibuat.');
    }

    public function update(Request $request, $id)
    {
        // Validasi input
        $validator = Validator::make($request->all(), [
            'NAMA_PENITIP' => 'required|string|max:255',
            'EMAIL_PENITIP' => 'required|email|max:255|unique:penitip,EMAIL_PENITIP,' . $id . ',ID_PENITIP',
            'ALAMAT_PENITIP' => 'required|string|max:255',
            'NIK' => 'required|string|max:16',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $penitip = Penitip::findOrFail($id);

        // Update penitip
        $penitip->update([
            'NAMA_PENITIP' => $request->NAMA_PENITIP,
            'EMAIL_PENITIP' => $request->EMAIL_PENITIP,
            'ALAMAT_PENITIP' => $request->ALAMAT_PENITIP,
            'NIK' => $request->NIK,
        ]);

        return redirect()->back()->with('success', 'Data Jabatan berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $penitip = Penitip::findOrFail($id);

        // Hapus file SCAN_KTP jika ada
        if ($penitip->SCAN_KTP) {
            Storage::disk('public')->delete($penitip->SCAN_KTP);
        }

        // Hapus penitip
        $penitip->delete();

        return redirect()->back()->with('success', 'Data penitip berhasil dihapus.');
    }

    public function search(Request $request)
    {
        // Menyaring berdasarkan nama penitip
        $penitips = Penitip::query()
            ->when($request->input('NAMA_PENITIP'), function ($query, $nama) {
                return $query->where('NAMA_PENITIP', 'like', '%' . $nama . '%');
            })
            ->get();

        return view('CSForPenitip', compact('penitips'));
    }

public function history($penitipId){

$data= DB::table('penitipan')
            ->join('barang', 'barang.ID_PENITIPAN', '=', 'penitipan.ID_PENITIPAN')
            ->join('penitip', 'penitipan.ID_PENITIP', '=', 'penitip.ID_PENITIP')
            ->where('penitipan.ID_PENITIP', $penitipId)
            ->distinct()
            ->select(
                'barang.ID_BARANG',
                'barang.NAMA_BARANG',
                'barang.HARGA_BARANG',
                'penitipan.ID_PENITIPAN',
                'penitipan.TANGGAL_PENITIPAN',
                'penitipan.TANGGAL_BERAKHIR',
                'penitipan.STATUS_PERPANJANGAN',
                'barang.DESKRIPSI_BARANG',
                'barang.STATUS_BARANG',
                'penitip.ID_PENITIP',
                'penitip.NAMA_PENITIP',
                'penitip.EMAIL_PENITIP'
            )
            ->get();

        if ($data->isEmpty()) {
            abort(404, 'Data penitipan tidak ditemukan.');
        }

        return view('historyPenitipan', [
            'riwayatPenitipan' => $data,
        ]);

    }

    public function perpanjang($id)
{
    $penitipan = DB::table('penitipan')->where('ID_PENITIPAN', $id)->first();

    if (!$penitipan) {
        return redirect()->back()->with('error', 'Data penitipan tidak ditemukan.');
    }

    $tanggalBaru = Carbon::parse($penitipan->TANGGAL_BERAKHIR)->addDays(30);

    DB::table('penitipan')->where('ID_PENITIPAN', $id)->update([
        'TANGGAL_BERAKHIR' => $tanggalBaru,
        'STATUS_PERPANJANGAN' => 1 // 1 = disetujui
    ]);


    return redirect()->back()->with('success', 'Perpanjangan berhasil dilakukan.');
}

}
