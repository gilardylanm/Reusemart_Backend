<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\Pembeli;
use App\Models\Pegawai;
use App\Models\Penitip;
use App\Models\Organisasi;
use App\Models\Request_Donasi;
use Log;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $email = $request->email;
        $password = $request->password;

// Cek di tabel pembeli
    $pembeli = Pembeli::where('EMAIL_PEMBELI', $email)->first();
    
    if ($pembeli && Hash::check($password, $pembeli->PASSWORD_PEMBELI)) {
        // Simpan data ke session
        session([
            'user_type' => 'pembeli',
            'user_id' => $pembeli->ID_PEMBELI, // Pastikan ini nama kolom yang benar
            'user_email' => $pembeli->EMAIL_PEMBELI
        ]);
        
        return redirect()->route('halamanPembeli');
    }
    
// Cek di tabel Pegawai
$pegawai = Pegawai::where('EMAIL_PEGAWAI', $email)->first();

if ($pegawai && Hash::check($password, $pegawai->PASSWORD_PEGAWAI)) {
    // Simpan data ke session dengan struktur yang sama seperti pembeli
    session([
        'user_type' => 'pegawai',
        'user_id' => $pegawai->ID_PEGAWAI,
        'user_email' => $pegawai->EMAIL_PEGAWAI
    ]);
    
    return redirect()->route('adminForPegawai');
}

        // Cek di tabel penitip
        $penitip = Penitip::where('EMAIL_PENITIP', $email)->first();
        if ($penitip && Hash::check($password, $penitip->PASSWORD_PENITIP)) {
            session(['user_type' => 'penitip', 'user_id' => $penitip->ID_PENITIP]);
            return redirect()->route('halamanPenitip');
        }

        // Cek di tabel organisasi
        $organisasi = Organisasi::where('EMAIL_ORGANISASI', $email)->first();
        if ($organisasi && Hash::check($password, $organisasi->PASSWORD_ORGANISASI)) {
            session(['user_type' => 'organisasi', 'user_id' => $organisasi->ID_ORGANISASI]);
            $requestList = Request_Donasi::where('ID_ORGANISASI', $organisasi->ID_ORGANISASI)->get();
            
            // Kirim ke view 'organisasi'
            return view('organisasi', [
                'organisasi' => $organisasi,
                'requestList' => $requestList,
            ]);
        }

        return back()->withErrors(['email' => 'Email atau password salah']);
    }

    public function logout()
    {
        session()->flush(); // Hapus semua session
        return redirect()->route('login.form'); // Redirect ke halaman login
    }
}
