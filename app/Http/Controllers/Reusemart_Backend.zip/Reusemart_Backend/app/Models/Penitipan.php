<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Penitipan extends Model
{
    protected $table = 'penitipan'; // nama tabel di database

    protected $primaryKey = 'ID_PENITIPAN';
    public $incrementing = true; // karena ID bukan auto-increment
    protected $keyType = 'int'; // karena ID-nya seperti "PG.1"

    public $timestamps = false; // jika tidak ada kolom created_at dan updated_at

    protected $fillable = [
        'ID_PENITIPAN',
        'ID_PENITIP',
        'ID_PEGAWAI',
        'TANGGAL_PENITIPAN',
        'TANGGAL_BERAKHIR',
        'STATUS_PERPANJANGAN',
        'BATAS_AMBIL',
        'STATUS_AMBIL_KEMBALI',
    ];



    // Relasi ke model Penitip
    public function penitip(): BelongsTo
    {
        return $this->belongsTo(Penitip::class, 'ID_PENITIP', 'ID_PENITIP');
    }

    // Relasi ke model Pegawai
    public function pegawai(): BelongsTo
    {
        return $this->belongsTo(Pegawai::class, 'ID_PEGAWAI', 'ID_PEGAWAI');
    }

    public function detailBarang(): BelongsTo
    {
        return $this->belongsTo(Penitip::class, 'ID_PENITIP', 'ID_BARANG');
    }

    public function barang()
    {
        return $this->hasMany(Barang::class, 'ID_PENITIPAN');
    }


}
