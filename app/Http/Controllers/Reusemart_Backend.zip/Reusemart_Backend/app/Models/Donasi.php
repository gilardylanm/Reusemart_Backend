<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Donasi extends Model
{
    use HasFactory;

    // Nama tabel di database
    protected $table = 'donasi';

    // Primary key sesuai kolom di tabel
    protected $primaryKey = 'ID_DONASI';

    // Jika primary key bukan auto-increment integer, atur ini:
    // public $incrementing = false;

    // Jika kolom primary key tipe string, tambahkan:
    // protected $keyType = 'string';

    // Jika tidak ada kolom timestamps (created_at, updated_at)
    public $timestamps = false;

    // Kolom yang boleh diisi massal
    protected $fillable = [
        'ID_REQUEST',
        'ID_BARANG',
        'TANGGAL_DONASI',
        'NAMA_PENERIMA',
    ];

    // Casting kolom ke tipe data tertentu
    protected $casts = [
        'TANGGAL_DONASI' => 'date',
    ];
}
