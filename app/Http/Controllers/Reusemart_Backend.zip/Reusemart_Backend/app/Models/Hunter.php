<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Hunter extends Model
{
    protected $table = 'penitipan'; // nama tabel di database

    protected $primaryKey = 'ID_HUNTER';

    public $timestamps = false; // jika tidak ada kolom created_at dan updated_at

    protected $fillable = [
        'NAMA_HUNTER',
        'EMAIL_HUNTER',
        'PASSWORD_HUNTER',
        'SALDO_HUNTER'
    ];



    // Relasi ke model Penitip
    public function penitip(): BelongsTo
    {
        return $this->belongsTo(Penitip::class, 'ID_PENITIP', 'ID_PENITIP');
    }

    public function barang()
    {
        return $this->hasMany(Barang::class, 'ID_PENITIPAN');
    }

        public function penitipan()
    {
        return $this->hasMany(Penitipan::class, 'ID_BARANG');
    }


}
