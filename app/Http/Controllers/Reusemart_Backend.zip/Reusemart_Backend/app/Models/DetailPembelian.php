<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetailPembelian extends Model
{
    protected $table = 'detailpembelian';
    public $timestamps = false;
    public $incrementing = false; // karena tidak ada primary key auto increment

    protected $fillable = [
        'ID_PEMBELIAN',
        'ID_BARANG'
    ];

    public function pembelian()
    {
        return $this->belongsTo(Pembelian::class, 'ID_PEMBELIAN');
    }

    public function barang()
    {
        return $this->belongsTo(Barang::class, 'ID_BARANG');
    }
}
