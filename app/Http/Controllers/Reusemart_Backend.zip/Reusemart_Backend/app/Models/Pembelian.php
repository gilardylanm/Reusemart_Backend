<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pembelian extends Model
{
    protected $table = 'pembelian';
    protected $primaryKey = 'ID_PEMBELIAN';
    public $timestamps = false;
        protected $fillable = [
        'ID_PEMBELI',
        'ID_ALAMAT',
        'ID_BARANG',
        'TANGGAL_PEMBELIAN',
        'TANGGAL_LUNAS',
        'TANGGAL_AMBIL',
        'TANGGAL_PENGIRIMAN',
        'TANGGAL_DITERIMA',
        'SUBTOTAL',
        'TOTAL_BAYAR',
        'STATUS_PEMBAYARAN',
        'POIN_DIGUNAKAN',
        'POIN_DIDAPAT',
        'METODE_PENGIRIMAN',
        'BUKTI_PEMBAYARAN',
        'STATUS_PENGIRIMAN',
        'STATUS_PENGAMBILAN',
        'KOMISI_REUSEMART',
        'JUMLAH_TERJUAL'
    ];

    public function pembeli()
    {
        return $this->belongsTo(Pembeli::class, 'ID_PEMBELI');
    }

    public function detail()
    {
        return $this->hasMany(DetailPembelian::class, 'ID_PEMBELIAN');
    }
    
}
