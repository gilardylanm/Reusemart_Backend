<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Barang extends Model
{
    protected $table = 'barang';
    protected $primaryKey = 'ID_BARANG';
    public $timestamps = false;

    protected $fillable = [
        'ID_PENITIPAN',
        'ID_PEGAWAI',
        'NAMA_BARANG',
        'HARGA_BARANG',
        'DESKRIPSI_BARANG',
        'GARANSI',
        'BERAT',
        'KATEGORI_BARANG',
        'STATUS_BARANG'
    ];

    public function penitipan()
    {
        return $this->belongsTo(Penitipan::class, 'ID_PENITIPAN');
    }

        public function detailPembelian()
    {
        return $this->hasMany(DetailPembelian::class, 'ID_BARANG');
    }

    public function rating()
    {
        return $this->hasMany(Rating::class, 'ID_BARANG');
    }

}