<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Request extends Model
{
    protected $table = 'requestdonasi';
    protected $primaryKey = 'ID_REQUEST';

    protected $fillable = [
        'NAMA_BARANG',
        'DESKRIPSI_REQUEST',
        'TANGGAL_REQUEST',
        'STATUS_REQUEST',
    ];
}

