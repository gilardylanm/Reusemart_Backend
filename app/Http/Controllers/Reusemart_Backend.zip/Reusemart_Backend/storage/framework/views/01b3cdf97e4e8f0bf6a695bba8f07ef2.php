<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Penjualan Bulanan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
        }
        .container {
            margin: 20px;
        }
        .header {
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            border: 1px solid black;
            padding: 6px 10px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .text-start {
            text-align: left;
        }
        .text-bold {
            font-weight: bold;
        }
        .underline {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="text-start">
        <p class="text-bold">ReUse Mart</p>
        <p>Jl. Green Eco Park No. 456 Yogyakarta</p>

        <p class="underline text-bold">LAPORAN PENJUALAN BULANAN</p>
        <p>Tahun : <?php echo e(\Carbon\Carbon::now()->format('Y')); ?></p>
        <p>Tanggal cetak: <?php echo e(\Carbon\Carbon::now()->translatedFormat('j F Y')); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Bulan</th>
                <th>Jumlah Barang Terjual</th>
                <th>Jumlah Penjualan Kotor</th>
            </tr>
        </thead>
        <tbody>
            <?php $totalBarang = 0; $totalPenjualan = 0; ?>
            <?php $__currentLoopData = $dataPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($bulan); ?></td>
                    <td><?php echo e($data['jumlah_terjual']); ?></td>
                    <td><?php echo e(number_format($data['penjualan_kotor'], 0, ',', '.')); ?></td>
                </tr>
                <?php
                    $totalBarang += $data['jumlah_terjual'];
                    $totalPenjualan += $data['penjualan_kotor'];
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-bold">Total</td>
                <td class="text-bold"><?php echo e($totalBarang); ?></td>
                <td class="text-bold"><?php echo e(number_format($totalPenjualan, 0, ',', '.')); ?></td>
            </tr>
        </tbody>
    </table>
</div>
</body>
</html>
<?php /**PATH D:\Reusemart\Reusemart\Reusemart_Backend\resources\views/notaBarangs.blade.php ENDPATH**/ ?>