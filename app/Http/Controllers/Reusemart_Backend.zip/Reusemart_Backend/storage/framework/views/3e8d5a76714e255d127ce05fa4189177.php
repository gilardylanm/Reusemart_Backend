<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pembeli - ReuseMart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            background-color: #0D5C4F;
            color: #333;
        }
        
        /* Header styles */
        header {
            background-color: white;
            padding: 10px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .address-set-primary {
            cursor: pointer;
            color: blue;
        }

        .address-set-primary:hover {
            color: white; /* Ubah warna teks saat hover */
            background-color: #007BFF; /* Warna latar belakang saat hover */
            padding: 0 5px; /* Menambahkan padding untuk memberi ruang di sekitar teks */
            border-radius: 3px; /* Menambahkan sudut membulat pada latar belakang */
        }
        
        nav {
            display: flex;
            gap: 30px;
        }
        
        nav a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            font-size: 18px;
        }
        
        /* Main content styles */
        .container {
            max-width: 850px;
            margin: 20px auto;
            display: grid;
            /* Updated grid layout to 2 columns */
            grid-template-columns: 2fr 1fr;
            grid-template-rows: auto auto;
            gap: 20px;
        }
    
        /* Make the profile settings take the first cell (left) */
        .card:nth-child(1) {
            grid-column: 1;
            grid-row: 1;
        }
    
        /* Make the reward points take the second cell (right) */
        .card:nth-child(2) {
            grid-column: 2;
            grid-row: 1;
            height: 350px; /* Fixed height for the reward card */
        }
    
        /* Make the address settings take the third cell (spanning full width) */
        .card:nth-child(3) {
            grid-column: 1 / span 2; /* Span across both columns */
            grid-row: 2;
        }
        
        .card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .card-header {
            color: #0D5C4F;
            font-size: 22px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        
        /* Profile settings styles */
        .profile-field {
            margin-bottom: 15px;
        }
        
        .profile-field label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .profile-field input {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background: linear-gradient(135deg, #0D5C4F, #1a9e85);
            color: white;
            font-size: 16px;
        }
        
        /* Address styles */
        .address-section {
            margin-bottom: 30px;
        }

        .address-buttons {
            display: flex;
            gap: 10px; /* Jarak antara kedua tombol */
        }
        
        .address-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .add-address-btn {
            background-color: #0D5C4F;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 8px 15px;
            font-size: 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            margin-left: auto; /* Ubah dari margin-left: 45%; menjadi auto untuk meletakkannya di kanan */
        }

        .save-addresses-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 8px 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .save-addresses-btn:hover {
            background-color: #45a049;
        }
        
        .address-list {
            padding-top: 3%;
            display: flex;
            flex-direction: column;
            gap: 20px;
            max-height: 400px; /* Set maximum height */
            overflow-y: auto; /* Add vertical scrollbar when needed */
        }
        
        .address-item {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .address-text {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            width: 70%;
        }
        
        .address-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .address-set-primary {
            font-size: 14px;
            color: #555;
        }

        /* Styling for the search input container */
        .search-address-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }

        /* Styling for the search input */
        .search-address-input {
            padding-left: 30px; /* To make room for the icon */
            width: 40%;
            padding: 5px 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        
        .btn-edit, .btn-delete {
            width: 30px;
            height: 30px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .btn-edit {
            background-color: #3F51B5;
            color: white;
        }
        
        .btn-delete {
            background-color: #F44336;
            color: white;
        }

        .input-with-icon {
            position: relative;
            width: 80%;
        }

        .input-with-icon i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: white;
            z-index: 1;
        }

        .input-with-icon input {
            width: 100%;
            padding: 10px 10px 10px 35px; /* Tambahkan padding kiri untuk ikon */
            border: 1px solid #ccc;
            border-radius: 5px;
            background: linear-gradient(135deg, #0D5C4F, #1a9e85);
            color: white;
            font-size: 16px;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            overflow: auto;
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            animation: modalopen 0.3s;
        }

        @keyframes modalopen {
            from {opacity: 0; transform: translateY(-50px);}
            to {opacity: 1; transform: translateY(0);}
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .modal-header h3 {
            color: #0D5C4F;
            margin: 0;
        }

        .close-modal {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close-modal:hover {
            color: #333;
        }

        .modal-form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .modal-form-group {
            margin-bottom: 15px;
        }

        .modal-form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #555;
        }

        .modal-form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .modal-form-group:nth-child(1) {
            grid-column: 1 / span 2;
        }

        .modal-form-group:nth-child(2) {
            grid-column: 1 / span 2;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            margin-top: 20px;
            gap: 10px;
        }

        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
        }

        .modal-btn-cancel {
            background-color: #ddd;
            color: #333;
        }

        .modal-btn-save {
            background-color: #0D5C4F;
            color: white;
        }

        .modal-btn:hover {
            opacity: 0.9;
        }
        
        /* Responsive styles */
        @media (max-width: 768px) {
            .container {
                grid-template-columns: 1fr;
                padding: 0 15px;
            }
            
            .card:nth-child(1), .card:nth-child(2), .card:nth-child(3) {
                grid-column: 1;
            }
            
            .card:nth-child(2) {
                grid-row: 2;
            }
            
            .card:nth-child(3) {
                grid-row: 3;
            }
            
            header {
                flex-direction: column;
                padding: 10px;
            }
            
            nav {
                margin-top: 10px;
                gap: 15px;
            }

            .modal-content {
                width: 95%;
                margin: 20% auto;
            }

            .modal-form {
                grid-template-columns: 1fr;
            }

            .modal-form-group:nth-child(1),
            .modal-form-group:nth-child(2) {
                grid-column: 1;
            }
        }
    </style>
</head>
<body>
    <!-- Header with navigation -->
    <header>
        <div class="logo">
            <img src="/img/Logo ReuseMart.jpg" alt="ReuseMart Logo">
        </div>
        <nav>
            <a href="/halamanPembeli">Beranda</a>
            <a href="#">Keranjang</a>
            <a href="#">History</a>
            <a href="/profilPembeli">Profil Akun</a>
        </nav>
    </header>
    
    <!-- Main content -->
    <div class="container">
        <!-- Profile settings -->
        <div class="card">
            <h2 class="card-header">Profil Pembeli</h2>
            <div class="profile-field">
                <label for="nama">Nama Pembeli</label>
                <div class="input-with-icon">
                    <i class="fa fa-user"></i>
                    <input type="text" id="nama" value="Thomas Adi" readonly>
                </div>
            </div>
            <div class="profile-field">
                <label for="telepon">Nomor Telepon</label>
                <div class="input-with-icon">
                    <i class="fa fa-phone"></i>
                    <input type="text" id="telepon" value="081343336270" readonly>
                </div>
            </div>
            <div class="profile-field">
                <label for="email">Email</label>
                <div class="input-with-icon">
                    <i class="fa fa-envelope"></i>
                    <input type="email" id="email" value="thomas@gmail.com" readonly>
                </div>
            </div>
        </div>
        
        <!-- Reward points (dengan desain baru dan height yang sama) -->
        <div class="card">
            <h2 class="card-header">Poin Reward</h2>
            <div class="reward-container" style="
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: space-between;
                height: calc(100% - 55px); /* Mengakomodasi tinggi header */
            ">
                <div class="reward-points" style="
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    width: 150px;
                    height: 150px;
                    background: linear-gradient(135deg, #0D5C4F, #8BC34A);
                    border-radius: 5%;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                    margin: 10px 0;
                ">
                    <div class="points" style="
                        font-size: 50px;
                        font-weight: bold;
                        color: white;
                        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
                    ">120</div>
                    <div style="
                        color: white;
                        font-size: 14px;
                        text-transform: uppercase;
                        letter-spacing: 1px;
                    ">points</div>
                </div>
                
                <div class="reward-info" style="
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    margin-bottom: 20px;
                ">
                    <div style="
                        font-size: 16px;
                        color: #555;
                        margin-top: 20px;
                        margin-bottom: 20px;
                        text-align: center;
                    ">Tukarkan poin Anda dengan Merchadise</div>
                    
                    <button style="
                        background-color: #ebb734;
                        color: white;
                        border: none;
                        border-radius: 20px;
                        padding: 10px 20px;
                        font-weight: bold;
                        cursor: pointer;
                        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                        transition: all 0.3s ease;
                    ">Tukar Poin</button>
                </div>
            </div>
        </div>
        
        <!-- Address settings -->
        <div class="card">
            <div class="address-header">
                <h2 class="card-header">Pengaturan Alamat</h2>
                <button class="add-address-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                    </svg>
                    Tambah Alamat
                </button> 
            </div>
            <!-- Search input for addresses with icon -->
            <div class="search-address-wrapper">
                <input type="text" id="search-address" placeholder="Cari Alamat Anda..." class="search-address-input">
            </div>
            <div class="address-list">
                <!-- Address items will be added dynamically -->
            </div>
        </div>
    </div>

    <!-- Modal for adding new address -->
    <div id="addressModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Tambah Alamat Baru</h3>
                <span class="close-modal">&times;</span>
            </div>
            <form id="addressForm">
                <div class="modal-form">
                    <div class="modal-form-group">
                        <label for="label">Label Alamat</label>
                        <input type="text" id="label" placeholder="Contoh: Rumah, Kantor, dll" required>
                    </div>
                    <div class="modal-form-group">
                        <label for="jalan">Alamat Jalan</label>
                        <input type="text" id="jalan" placeholder="Masukkan alamat lengkap" required>
                    </div>
                    <div class="modal-form-group">
                        <label for="kelurahan">Kelurahan</label>
                        <input type="text" id="kelurahan" placeholder="Masukkan kelurahan" required>
                    </div>
                    <div class="modal-form-group">
                        <label for="kecamatan">Kecamatan</label>
                        <input type="text" id="kecamatan" placeholder="Masukkan kecamatan" required>
                    </div>
                    <div class="modal-form-group">
                        <label for="kota">Kota/Kabupaten</label>
                        <input type="text" id="kota" placeholder="Masukkan kota/kabupaten" required>
                    </div>
                    <div class="modal-form-group">
                        <label for="kodepos">Kode Pos</label>
                        <input type="text" id="kodepos" placeholder="Masukkan kode pos" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="modal-btn modal-btn-cancel" id="cancelAddress">Batal</button>
                    <button type="submit" class="modal-btn modal-btn-save">Simpan Alamat</button>
                </div>
            </form>
        </div>
    </div>

    <!-- JavaScript for interactions -->
    <script>
       // Modal functionality
        const modal = document.getElementById('addressModal');
        const addAddressBtn = document.querySelector('.add-address-btn');
        const closeModal = document.querySelector('.close-modal');
        const cancelBtn = document.getElementById('cancelAddress');
        const addressForm = document.getElementById('addressForm');

        // Tambahkan variabel global untuk melacak mode dan item yang sedang diedit
        let isEditMode = false;
        let currentEditItem = null;

        // Fungsi untuk membuka modal
        function openModal(mode, addressItem = null) {
            isEditMode = mode === 'edit';
            currentEditItem = addressItem;
            
            // Ubah judul modal berdasarkan mode
            document.querySelector('.modal-header h3').textContent = isEditMode ? 'Edit Alamat' : 'Tambah Alamat Baru';
            
            // Jika mode edit, isi form dengan data alamat yang ada
            if (isEditMode && addressItem) {
                const addressText = addressItem.querySelector('.address-text').value;
                
                // Parse alamat untuk mengisi form
                // Format alamat: "Label: Jalan, Kel. Kelurahan, Kec. Kecamatan, Kota, Kodepos"
                try {
                    const labelMatch = addressText.match(/(.*?):/);
                    const label = labelMatch ? labelMatch[1].trim() : '';
                    
                    const jalanMatch = addressText.match(/: (.*?), Kel\./);
                    const jalan = jalanMatch ? jalanMatch[1].trim() : '';
                    
                    const kelurahanMatch = addressText.match(/Kel\. (.*?), Kec\./);
                    const kelurahan = kelurahanMatch ? kelurahanMatch[1].trim() : '';
                    
                    const kecamatanMatch = addressText.match(/Kec\. (.*?),/);
                    const kecamatan = kecamatanMatch ? kecamatanMatch[1].trim() : '';
                    
                    const kotaMatch = addressText.match(/Kec\. .*?, (.*?),/);
                    const kota = kotaMatch ? kotaMatch[1].trim() : '';
                    
                    const kodeposMatch = addressText.match(/, ([0-9]+)$/);
                    const kodepos = kodeposMatch ? kodeposMatch[1].trim() : '';
                    
                    // Isi form dengan data yang di-parse
                    document.getElementById('label').value = label;
                    document.getElementById('jalan').value = jalan;
                    document.getElementById('kelurahan').value = kelurahan;
                    document.getElementById('kecamatan').value = kecamatan;
                    document.getElementById('kota').value = kota;
                    document.getElementById('kodepos').value = kodepos;
                } catch (e) {
                    console.error('Error parsing address:', e);
                }
            } else {
                // Reset form jika mode tambah
                addressForm.reset();
            }
            
            // Tampilkan modal
            modal.style.display = 'block';
        }

        // Ubah event listener untuk tombol tambah alamat
        addAddressBtn.addEventListener('click', function() {
            openModal('add');
        });

        // Close modal when close button is clicked
        closeModal.addEventListener('click', function() {
            modal.style.display = 'none';
        });

        // Close modal when cancel button is clicked
        cancelBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });

        // Close modal when clicking outside of it
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });

        // Handle form submission
        addressForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const label = document.getElementById('label').value;
            const jalan = document.getElementById('jalan').value;
            const kelurahan = document.getElementById('kelurahan').value;
            const kecamatan = document.getElementById('kecamatan').value;
            const kota = document.getElementById('kota').value;
            const kodepos = document.getElementById('kodepos').value;
            
            // Create address string
            const addressString = `${label}: ${jalan}, Kel. ${kelurahan}, Kec. ${kecamatan}, ${kota}, ${kodepos}`;
            
            if (isEditMode && currentEditItem) {
                // Update alamat yang sudah ada
                currentEditItem.querySelector('.address-text').value = addressString;
            } else {
                // Tambah alamat baru
                addAddressToList(addressString);
            }
            
            // Reset form dan tutup modal
            addressForm.reset();
            modal.style.display = 'none';
            
            // Reset variabel mode
            isEditMode = false;
            currentEditItem = null;
        });

        // Function to add address to the list
        function addAddressToList(addressString) {
            const addressList = document.querySelector('.address-list');
            const newAddress = document.createElement('div');
            newAddress.className = 'address-item';
            newAddress.innerHTML = `
                <input type="text" class="address-text" value="${addressString}" readonly>
                <div class="address-actions">
                    <div class="address-set-primary">Atur Sebagai Utama</div>
                    <button class="btn-edit">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3 9.293V13h3.5L13.207 6.207a.5.5 0 0 0 0-.707z"/>
                        </svg>
                    </button>
                    <button class="btn-delete">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                        </svg>
                    </button>
                </div>
            `;
            addressList.appendChild(newAddress);
            
            // Add event listeners to new buttons
            setupAddressItemEventListeners(newAddress);
        }

        // Function to set up event listeners for address item buttons
        function setupAddressItemEventListeners(addressItem) {
            const editBtn = addressItem.querySelector('.btn-edit');
            const deleteBtn = addressItem.querySelector('.btn-delete');
            const setPrimaryBtn = addressItem.querySelector('.address-set-primary');
            
            editBtn.addEventListener('click', function() {
                // Panggil fungsi openModal dengan mode 'edit' dan item yang akan diedit
                openModal('edit', this.closest('.address-item'));
            });
            
            deleteBtn.addEventListener('click', function() {
                this.closest('.address-item').remove();
            });
            
            setPrimaryBtn.addEventListener('click', function() {
                const addressItem = this.closest('.address-item');
                const addressList = document.querySelector('.address-list');
                addressList.prepend(addressItem);
            });
        }

        // Add event listener for the save button (jika ada)
        const saveAddressesBtn = document.querySelector('.save-addresses-btn');
        if (saveAddressesBtn) {
            saveAddressesBtn.addEventListener('click', function() {
                // Simpan semua alamat
                const addresses = [];
                document.querySelectorAll('.address-item input').forEach(input => {
                    addresses.push(input.value);
                });
                
                // Di sini Anda bisa menambahkan kode untuk menyimpan alamat ke server
                // Contoh: fetch API call ke endpoint backend
                
                // Tampilkan pesan konfirmasi
                alert('Alamat berhasil disimpan!');
            });
        }

        // Search functionality
        const searchAddressInput = document.querySelector('#search-address');
        if (searchAddressInput) {
            searchAddressInput.addEventListener('input', function() {
                const searchQuery = this.value.toLowerCase();
                const addressItems = document.querySelectorAll('.address-item');
                
                addressItems.forEach(item => {
                    const addressText = item.querySelector('.address-text').value.toLowerCase();
                    
                    // Sembunyikan alamat yang tidak sesuai dengan pencarian
                    if (addressText.includes(searchQuery)) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        }
    </script>
</body>
</html><?php /**PATH D:\Reusemart\Reusemart\Reusemart_Backend\resources\views/ProfilPembeli.blade.php ENDPATH**/ ?>