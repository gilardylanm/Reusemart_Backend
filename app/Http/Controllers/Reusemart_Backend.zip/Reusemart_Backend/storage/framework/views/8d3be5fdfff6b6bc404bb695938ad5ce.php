<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transaksi Penitipan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color: #2d7c2d;">

<div class="container mt-4 p-4 rounded">
    <div class="bg-white p-4 rounded shadow">

        <?php
            $penitipanInfo = $barangList->first();
        ?>

        <?php if($penitipanInfo): ?>
            <h4 class="fw-bold">Transaksi Penitipan milik: <?php echo e($penitipanInfo->NAMA_PENITIP); ?></h4>
            <p class="mb-4">Tanggal Penitipan : <?php echo e($penitipanInfo->TANGGAL_PENITIPAN); ?></p>
        <?php else: ?>
            <h4 class="fw-bold">Tidak ada data penitipan tersedia.</h4>
        <?php endif; ?>


        <div class="mb-3 text-end">
          <?php if($barangList->isNotEmpty()): ?>
              <a href="<?php echo e(route('cetak.nota', $barangList[0]->ID_PENITIPAN)); ?>" target="_blank" class="btn btn-secondary">
                  Cetak Nota
              </a>
          <?php endif; ?>            
          <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createBarangModal">Create Barang</a>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <table class="table table-bordered text-center">
            <thead class="table-light">
                <tr>
                    <th>ID Barang</th>
                    <th>Nama Barang</th>
                    <th>Harga Barang</th>
                    <th>Status Penitipan</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $barangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($barang->ID_BARANG); ?></td>  
                    <td><?php echo e($barang->NAMA_BARANG); ?></td>
                    <td><?php echo e(number_format($barang->HARGA_BARANG, 0, ',', '.')); ?></td>
                    <td><?php echo e($barang->STATUS_PERPANJANGAN == 1 ? 'Aktif' : 'Tidak Aktif'); ?></td>
                    <td>
                        <div class="d-flex justify-content-center gap-2">
                            <!-- Tombol Edit -->
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($barang->ID_BARANG); ?>">
                                Edit
                            </button>

                            <!-- Tombol Delete -->
                            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($barang->ID_BARANG); ?>">
                                Hapus
                            </button>
                        </div>
                    </td>
                </tr>

                <!-- Modal Edit -->
                <div class="modal fade" id="editModal<?php echo e($barang->ID_BARANG); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($barang->ID_BARANG); ?>" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form action="<?php echo e(route('update.barang', $barang->ID_BARANG)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                          <h5 class="modal-title">Edit Barang</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          <div class="mb-3">
                            <label class="form-label">Nama Barang</label>
                            <input type="text" name="NAMA_BARANG" class="form-control" value="<?php echo e($barang->NAMA_BARANG); ?>" required>
                          </div>
                          <div class="mb-3">
                            <label class="form-label">Harga Barang</label>
                            <input type="number" name="HARGA_BARANG" class="form-control" value="<?php echo e($barang->HARGA_BARANG); ?>" required>
                          </div>
                          <div class="mb-3">
                            <label class="form-label">Status Perpanjangan</label>
                            <select name="STATUS_PERPANJANGAN" class="form-select" required>
                              <option value="1" <?php echo e($barang->STATUS_PERPANJANGAN == 1 ? 'selected' : ''); ?>>Aktif</option>
                              <option value="0" <?php echo e($barang->STATUS_PERPANJANGAN == 0 ? 'selected' : ''); ?>>Tidak Aktif</option>
                            </select>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-success">Simpan</button>
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

                <!-- Modal Delete -->
                <div class="modal fade" id="deleteModal<?php echo e($barang->ID_BARANG); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($barang->ID_BARANG); ?>" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form action="<?php echo e(route('delete.barang', $barang->ID_BARANG)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-header">
                          <h5 class="modal-title">Hapus Barang</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          Apakah Anda yakin ingin menghapus <strong><?php echo e($barang->NAMA_BARANG); ?></strong>?
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-danger">Hapus</button>
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Tidak ada data barang yang ditemukan.</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
</div>

<!-- Modal Create Barang -->
<div class="modal fade" id="createBarangModal" tabindex="-1" aria-labelledby="createBarangLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo e(route('store.barang')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="ID_PENITIPAN" value="<?php echo e($idpenitipan); ?>">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Tambah Barang</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-2">
            <label class="form-label">Nama Barang</label>
            <input type="text" name="NAMA_BARANG" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Harga Barang</label>
            <input type="number" name="HARGA_BARANG" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Deskripsi Barang</label>
            <textarea name="DESKRIPSI_BARANG" class="form-control"></textarea>
          </div>
          <div class="mb-2">
            <label class="form-label">Garansi</label>
            <input type="date" name="GARANSI" class="form-control">
          </div>
          <div class="mb-2">
            <label class="form-label">Berat (gram)</label>
            <input type="number" name="BERAT" class="form-control">
          </div>
          <div class="mb-2">
            <label class="form-label">Kategori</label>
            <input type="text" name="KATEGORI_BARANG" class="form-control">
          </div>
          <div class="mb-2">
            <label class="form-label">Status Barang</label>
            <input type="text" name="STATUS_BARANG" class="form-control">
          </div>
          <div class="mb-2">
            <label class="form-label">Status Perpanjangan</label>
            <select name="STATUS_PERPANJANGAN" class="form-select" required>
              <option value="1">Aktif</option>
              <option value="0">Tidak Aktif</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<?php /**PATH D:\Reusemart\Reusemart\Reusemart_Backend\resources\views/transaksiPenitipan.blade.php ENDPATH**/ ?>