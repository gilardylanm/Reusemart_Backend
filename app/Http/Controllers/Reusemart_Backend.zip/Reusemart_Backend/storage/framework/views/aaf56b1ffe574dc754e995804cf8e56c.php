<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Nota Penitipan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .nota-container {
            border: 1px solid black;
            padding: 20px;
            width: 350px;
            margin: auto;
        }
        .text-small {
            font-size: 14px;
        }
        .fw-medium {
            font-weight: 500;
        }
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body class="p-4">

    <div class="nota-container">
        <div class="text-center fw-bold">ReUse Mart</div>
        <div class="text-center text-small">Jl. Green Eco Park No. 456 Yogyakarta</div>

        <div class="mt-3 text-small">
            <p>No Nota: <?php echo e($barangList[0]->NO_NOTA); ?></p>
            <div>Tanggal penitipan : <?php echo e(\Carbon\Carbon::parse($barangList[0]->TANGGAL_PENITIPAN)->format('d/m/Y H:i:s')); ?></div>
            <div>Masa penitipan sampai: <?php echo e(\Carbon\Carbon::parse($barangList[0]->TANGGAL_PENITIPAN)->addDays(30)->format('d/m/Y')); ?></div>

        </div>

        <div class="mt-3 text-small">
            <strong>Penitip :</strong> <?php echo e($barangList[0]->ID_PENITIP); ?> / <?php echo e($barangList[0]->NAMA_PENITIP); ?><br>
            <?php echo e($barangList[0]->ALAMAT_PENITIP); ?><br>
            Delivery: Kurir ReUseMart (<?php echo e($barangList[0]->NAMA_KURIR ?? '-'); ?>)
        </div>

        <div class="mt-3 text-small">
            <?php $__currentLoopData = $barangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-between">
                    <div><?php echo e($barang->NAMA_BARANG); ?></div>
                    <div>Rp <?php echo e(number_format($barang->HARGA_BARANG, 0, ',', '.')); ?></div>
                </div>
                <?php if(!empty($barang->GARANSI)): ?>
                    <div>Garansi <?php echo e($barang->GARANSI); ?></div>
                <?php endif; ?>
                <?php if(!empty($barang->BERAT)): ?>
                    <div>Berat barang: <?php echo e($barang->BERAT); ?> kg</div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<div class="mt-4 text-small">
    Diterima dan QC oleh: <?php echo e($barangList[0]->NAMA_PEGAWAI_GUDANG ?? '-'); ?>

</div>
    </div>

    <div class="text-center mt-3">
        <button onclick="window.print()" class="btn btn-primary no-print">Print Nota</button>
    </div>

</body>
</html>
<?php /**PATH D:\Reusemart\Reusemart\Reusemart_Backend\resources\views/notaBarang.blade.php ENDPATH**/ ?>