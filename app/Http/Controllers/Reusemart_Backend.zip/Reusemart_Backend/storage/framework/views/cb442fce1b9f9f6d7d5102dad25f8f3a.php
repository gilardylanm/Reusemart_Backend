<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Penjualan Bulanan</title>
    <style>
        @page {
            size: A4;
            margin: 1.5cm;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 13px;
            line-height: 1.5;
            color: #333;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .report-container {
            max-width: 210mm;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4CAF50;
        }
        .company-name {
            font-size: 24px;
            font-weight: bold;
            color: #4CAF50;
            margin-bottom: 5px;
        }
        .company-address {
            font-size: 12px;
            color: #666;
        }
        .report-title {
            font-size: 20px;
            font-weight: bold;
            margin: 15px 0 5px;
            color: #333;
            text-align: center;
        }
        .report-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 20px;
            font-size: 12px;
        }
        .report-info div {
            background-color: #f5f5f5;
            padding: 5px 15px;
            border-radius: 20px;
        }
        .chart-container {
            width: 100%;
            height: 300px;
            margin: 25px 0;
            background-color: #f9f9f9;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 0 5px rgba(0,0,0,0.05);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 13px;
        }
        th {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: bold;
        }
        td {
            padding: 8px 10px;
            border-bottom: 1px solid #eee;
        }
        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tbody tr:hover {
            background-color: #f1f8e9;
        }
        .total-row {
            font-weight: bold;
            background-color: #e8f5e9;
            border-top: 2px solid #4CAF50;
            border-bottom: 2px solid #4CAF50;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
        .no-data {
            color: #999;
            font-style: italic;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #666;
            padding-top: 15px;
            border-top: 1px dashed #ccc;
        }
        .print-btn {
            margin-top: 25px;
            text-align: center;
        }
        button {
            padding: 10px 25px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        button:hover {
            background-color: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        @media print {
            body {
                background-color: white;
                padding: 0;
                font-size: 12px;
            }
            .report-container {
                box-shadow: none;
                padding: 0;
            }
            .no-print {
                display: none !important;
            }
            th {
                background-color: #4CAF50 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="report-container">
    <div class="header">
        <div class="company-name">ReUse Mart</div>
        <div class="company-address">Jl. Green Eco Park No. 456 Yogyakarta</div>
    </div>

    <div class="report-title">LAPORAN PENJUALAN BULANAN</div>
    
    <div class="report-info">
        <div>Tahun: <?php echo e($tahun); ?></div>
        <div>Tanggal Cetak: <?php echo e($tanggalCetak); ?></div>
    </div>

    <div class="chart-container">
        <canvas id="salesChart"></canvas>
    </div>

    <table>
        <thead>
            <tr>
                <th>Bulan</th>
                <th class="text-right">Jumlah Terjual</th>
                <th class="text-right">Total Penjualan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bulanIndo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthNum => $namaBulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($namaBulan); ?></td>
                    <td class="text-right">
                        <?php if($dataPenjualan[$namaBulan]['JUMLAH_TERJUAL'] > 0): ?>
                            <?php echo e($dataPenjualan[$namaBulan]['JUMLAH_TERJUAL']); ?>

                        <?php else: ?>
                            <span class="no-data">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-right">
                        <?php if($dataPenjualan[$namaBulan]['penjualan_kotor'] > 0): ?>
                            Rp<?php echo e(number_format($dataPenjualan[$namaBulan]['penjualan_kotor'], 0, ',', '.')); ?>

                        <?php else: ?>
                            <span class="no-data">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="total-row">
                <td><strong>TOTAL</strong></td>
                <td class="text-right"><strong><?php echo e($totalBarang); ?></strong></td>
                <td class="text-right"><strong>Rp<?php echo e(number_format($totalPenjualan, 0, ',', '.')); ?></strong></td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        <p>Laporan ini dibuat secara otomatis oleh sistem ReUse Mart</p>
        <p>© <?php echo e(date('Y')); ?> ReUse Mart - All Rights Reserved</p>
    </div>

    <div class="print-btn no-print">
        <button onclick="window.print()">
            Cetak Laporan
        </button>
    </div>
</div>

<script>
    // Fungsi untuk mengumpulkan data dari tabel
    function getSalesDataFromTable() {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const salesData = {
            labels: months,
            datasets: [{
                label: 'Total Penjualan',
                data: new Array(12).fill(0),
                backgroundColor: 'rgba(75, 192, 192, 0.7)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
                borderRadius: 4,
                hoverBackgroundColor: 'rgba(75, 192, 192, 0.9)'
            }]
        };

        // Ambil data dari tabel
        const rows = document.querySelectorAll('table tbody tr:not(.total-row)');
        
        rows.forEach((row, index) => {
            const cells = row.querySelectorAll('td');
            const totalCell = cells[2].textContent.trim();
            
            let totalValue = 0;
            if (totalCell !== '-' && totalCell.includes('Rp')) {
                totalValue = parseInt(totalCell.replace(/[^\d]/g, ''));
            }
            
            salesData.datasets[0].data[index] = totalValue;
        });

        return salesData;
    }

    // Konfigurasi grafik batang
    const config = {
        type: 'bar',
        data: getSalesDataFromTable(),
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp' + value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                        },
                        stepSize: 1000000
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    },
                    title: {
                        display: true,
                        text: 'Total Penjualan (Rp)',
                        font: {
                            weight: 'bold'
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Bulan',
                        font: {
                            weight: 'bold'
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Total: Rp' + context.parsed.y.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                        },
                        title: function(context) {
                            return 'Bulan: ' + context[0].label;
                        }
                    },
                    backgroundColor: 'rgba(0,0,0,0.7)',
                    titleFont: {
                        size: 12,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 12
                    }
                }
            }
        }
    };

    // Buat grafik saat halaman dimuat
    window.onload = function() {
        const ctx = document.getElementById('salesChart').getContext('2d');
        new Chart(ctx, config);
    };
</script>
</body>
</html><?php /**PATH D:\Reusemart\Reusemart\Reusemart_Backend\resources\views/laporanBulanan.blade.php ENDPATH**/ ?>