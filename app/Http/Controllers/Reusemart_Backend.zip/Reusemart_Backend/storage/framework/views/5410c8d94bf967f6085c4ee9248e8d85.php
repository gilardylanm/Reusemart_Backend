<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Request Donasi - ReuseMart</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #0D5C4F;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 30px;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 40px;
        }

        .nav-links {
            display: flex;
            gap: 30px;
        }

        .nav-links a {
            text-decoration: none;
            color: black;
            font-size: 18px;
        }

        .container-fluid {
            padding: 40px;
        }

        .main-content {
            background-color: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .page-title {
            color: #18594a;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .btn-request {
            background-color: #18594a;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 20px;
            transition: background-color 0.3s ease;
        }

        .btn-request:hover {
            background-color: orange;
            color: black;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-box {
            position: relative;
            max-width: 400px;
        }

        .search-input {
            width: 100%;
            padding: 8px 40px 8px 15px;
            border-radius: 20px;
            border: 1px solid #ccc;
        }

        .search-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #777;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .table-header {
            background-color: #18594a;
            color: white;
        }

        .badge-menunggu {
            background-color: #ffc107;
            color: #000;
        }

        .badge-disetujui {
            background-color: #28a745;
        }

        .no-data-message {
            text-align: center;
            padding: 20px;
            font-style: italic;
            color: #777;
            display: none;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">
            <img src="img/Logo ReuseMart.jpg" alt="ReuseMart Logo">
        </div>
        <div class="nav-links">
            <a href="beranda.php">Beranda</a>
            <a href="/organisasi">Request Donasi</a>
            <a href="profilAkun.php">Profil Akun</a>
        </div>
    </div>

    <div class="container-fluid">
        <div class="main-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="page-title mb-0">Request Donasi</h2>

                <!-- Button to open modal for new request -->
                <button class="btn btn-request" data-bs-toggle="modal" data-bs-target="#requestModal">
                    <i class="fas fa-plus"></i> Request Donasi Baru
                </button>
            </div>

            <!-- Search container -->
            <div class="search-container">
                <div class="search-box">
                    <input type="text" class="search-input" id="searchInput" placeholder="Cari request donasi...">
                    <i class="fas fa-search search-icon"></i>
                </div>
            </div>

            <!-- Request table -->
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr class="table-header">
                            <th scope="col">Nama Barang</th>
                            <th scope="col">Deskripsi Request</th>
                            <th scope="col">Tanggal Request</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody id="requestTableBody">
                        <?php if(count($requestList) > 0): ?>
                            <?php foreach($requestList as $request): ?>
                                <tr>
                                    <td><?= $request->NAMA_BARANG ?></td>
                                    <td><?= $request->DESKRIPSI_REQUEST ?></td>
                                    <td><?= $request->TANGGAL_REQUEST ?></td>
                                    <td>
                                        <?php if($request->STATUS_REQUEST == 'Menunggu'): ?>
                                            <span class="badge badge-menunggu">Menunggu</span>
                                        <?php elseif($request->STATUS_REQUEST == 'Diterima'): ?>
                                            <span class="badge badge-disetujui">Diterima</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Ditolak</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Tombol Edit -->
                                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#editModal<?= $request->ID_REQUEST ?>">Edit</button>

                                        <!-- Tombol Hapus (dalam form) -->
                                        <form action="<?php echo e(route('requestdonasiorg.destroy', $request->ID_REQUEST)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                onclick="event.preventDefault(); 
                                                        if(confirm('Yakin ingin menghapus request ini?')) {
                                                            this.closest('form').submit();
                                                        }">
                                                Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php if(count($requestList) === 0): ?>
                    <div id="noDataMessage" class="no-data-message">Belum ada request donasi</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<!-- request donasi -->
<div class="modal fade" id="requestModal" tabindex="-1" aria-labelledby="requestModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('requestdonasi.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="requestModalLabel">Request Donasi Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="form-label">Nama Barang <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="NAMA_BARANG" 
                               value="<?php echo e(old('NAMA_BARANG')); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="DESKRIPSI_REQUEST" 
                                  rows="3" required><?php echo e(old('DESKRIPSI_REQUEST')); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Kirim Request</button>
                </div>
            </div>
        </form>
    </div>
</div>

   <!-- Edit Modals -->
<?php $__currentLoopData = $requestList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editModal<?php echo e($request->ID_REQUEST); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($request->ID_REQUEST); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('request.update', $request->ID_REQUEST)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel<?php echo e($request->ID_REQUEST); ?>">Edit Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Barang</label>
                        <input type="text" name="NAMA_BARANG" value="<?php echo e($request->NAMA_BARANG); ?>" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="DESKRIPSI_REQUEST" class="form-control" required><?php echo e($request->DESKRIPSI_REQUEST); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="STATUS_REQUEST" class="form-select" required>
                            <option value="Menunggu" <?php echo e($request->STATUS_REQUEST == 'Menunggu' ? 'selected' : ''); ?>>Menunggu</option>
                            <option value="Diterima" <?php echo e($request->STATUS_REQUEST == 'Diterima' ? 'selected' : ''); ?>>Diterima</option>
                            <option value="Ditolak" <?php echo e($request->STATUS_REQUEST == 'Ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Search functionality
            const searchInput = document.getElementById('searchInput');
            
            searchInput.addEventListener('keyup', function () {
                const searchText = this.value.toLowerCase();
                const rows = document.querySelectorAll('#requestTableBody tr');
                
                rows.forEach(function (row) {
                    const text = row.textContent.toLowerCase();
                    if (text.includes(searchText)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        });
    </script>
    <?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-3" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<script>
    // Auto close alert after 5 seconds
    setTimeout(() => {
        document.querySelector('.alert').alert('close');
    }, 5000);
</script>
<?php endif; ?>
</body>
</html><?php /**PATH D:\Reusemart\Reusemart\Reusemart_Backend\resources\views/organisasi.blade.php ENDPATH**/ ?>