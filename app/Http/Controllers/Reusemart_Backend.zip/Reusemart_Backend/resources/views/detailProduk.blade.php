<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detail Produk - ReUseMart</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .product-detail-img {
            max-width: 95%;
            width: 260px; /* Ubah sesuai kebutuhan */
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }


        .container {
            max-width: 1200px;
            margin-bottom: 10%;
        }

        .product-title {
            font-size: 2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }

        .product-price {
            font-size: 1.5rem;
            font-weight: 700;
            color: #007bff;
            margin-bottom: 15px;
        }

        .product-description {
            font-size: 1.1rem;
            color: #666;
            line-height: 1.5;
        }

        .product-info {
            margin-top: 10px;
        }

        .product-info p {
            font-weight: 500;
        }

        .comment-section {
            margin-top: 3rem;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .comment-header {
            font-size: 1.3rem;
            font-weight: 600;
            color: #333;
        }

        .comment-box {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            width: 100%;
            margin-bottom: 15px;
            font-size: 1rem;
            background-color: #f1f1f1;
            resize: vertical;
        }

        .submit-btn {
            background-color: #007bff;
            color: white;
            font-size: 1rem;
            font-weight: 600;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .comment-item {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .comment-item strong {
            color: #007bff;
        }

        .comment-item p {
            margin-top: 5px;
            color: #555;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding-left: 15px;
                padding-right: 15px;
            }

            .product-detail-img {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            <!-- Carousel untuk gambar produk -->
            <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <!-- Gambar pertama -->
                    <div class="carousel-item active">
                        <img src="img/iphone164.jpg" class="d-block w-100 product-detail-img" alt="IPhone 164 Pro Max">
                    </div>
                    <!-- Gambar kedua -->
                    <div class="carousel-item">
                        <img src="img/iphone163.jpg" class="d-block w-100 product-detail-img" alt="IPhone 163 Pro Max Back">
                    </div>
                </div>
                <!-- Kontrol carousel -->
                <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
        <div class="col-md-6">
            <h2 class="product-title">IPhone 16 Pro Max</h2>
            <p class="product-price">Rp16.000.000</p>
            <p class="product-description">Deskripsi: Smartphone canggih dengan berbagai fitur baru, termasuk kamera 108MP, layar OLED, dan chip terbaru. Dirancang untuk memberikan pengalaman yang luar biasa dalam performa dan desain.</p>

            <div class="product-info">
                <p class="fw-bold">Garansi: 1 Tahun (Sampai 13 Mei 2026)</p>
                <p class="fw-bold">Berat: 250g</p>
            </div>
            
            <!-- Diskusi / Komentar -->
            <div class="comment-section">
                <div class="comment-header">Diskusi Produk</div>
                <div id="discussion"></div>

                <textarea id="commentInput" class="comment-box" placeholder="Tinggalkan komentar..." rows="3"></textarea>
                <button class="submit-btn" onclick="submitComment()">Kirim Komentar</button>
            </div>
        </div>
    </div>
</div>


    <!-- Bootstrap JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        let comments = [
            { user: "Pembeli1", text: "Apakah produk ini masih tersedia?" },
            { user: "CS", text: "Ya, produk ini masih tersedia." }
        ];

        function displayComments() {
            const discussionDiv = document.getElementById('discussion');
            discussionDiv.innerHTML = "";
            comments.forEach(comment => {
                const commentElement = document.createElement('div');
                commentElement.classList.add('comment-item');
                commentElement.innerHTML = `<strong>${comment.user}:</strong> <p>${comment.text}</p>`;
                discussionDiv.appendChild(commentElement);
            });
        }

        function submitComment() {
            const commentInput = document.getElementById('commentInput');
            const newComment = commentInput.value;
            if (newComment) {
                comments.push({ user: "Pembeli", text: newComment });
                commentInput.value = '';
                displayComments();
            }
        }

        displayComments();
    </script>

</body>
</html>
