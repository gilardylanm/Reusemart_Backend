<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <title>Request Donasi - ReuseMart</title>
  <!-- Font Awesome for icons -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
  />
  <!-- Bootstrap CSS -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <style>
    /* CSS yang kamu punya */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body {
      background-color: #0d5c4f;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 30px;
      background-color: white;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .logo {
      display: flex;
      align-items: center;
    }

    .logo img {
      height: 40px;
    }

    .nav-links {
      display: flex;
      gap: 30px;
    }

    .nav-links a {
      text-decoration: none;
      color: black;
      font-size: 18px;
    }

    .container-fluid {
      padding: 40px;
    }

    .main-content {
      background-color: white;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .page-title {
      color: #18594a;
      margin-bottom: 30px;
      font-weight: bold;
    }

    .btn-request {
      background-color: #18594a;
      color: white;
      border: none;
      padding: 8px 20px;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
      margin-bottom: 20px;
      transition: background-color 0.3s ease;
    }

    .btn-request:hover {
      background-color: orange;
      color: black;
    }

    .search-container {
      margin-bottom: 20px;
    }

    .search-box {
      position: relative;
      max-width: 400px;
    }

    .search-input {
      width: 100%;
      padding: 8px 40px 8px 15px;
      border-radius: 20px;
      border: 1px solid #ccc;
    }

    .search-icon {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #777;
    }

    .data-table {
      width: 100%;
      border-collapse: collapse;
    }

    .table-header {
      background-color: #18594a;
      color: white;
    }

    .badge-menunggu {
      background-color: #ffc107;
      color: #000;
    }

    .badge-disetujui {
      background-color: #28a745;
    }

    .no-data-message {
      text-align: center;
      padding: 20px;
      font-style: italic;
      color: #777;
      display: none;
    }
  </style>
</head>
<body style="background-color: #0d5c4f;">
  <div class="container mt-3">
    <div class="card">
      <div class="card-body">
        <!-- Navbar -->
        <div class="navbar">
          <div class="logo">
            <img src="{{ asset('img/Logo ReuseMart.jpg') }}" alt="ReuseMart Logo" />
          </div>
          <div class="nav-links">       
            <a href="beranda.php">Beranda</a>
            <a href="/organisasi">Request Donasi</a>
            <a href="profilAkun.php">Profil Akun</a>
          </div>
        </div>

        <h2 class="mb-3 fw-bold">Penitipan Barang</h2>

                <!-- Tombol Tambah -->
<button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createPenitipanModal">
  Tambah Penitipan
</button>
    

        <!-- Input Pencarian -->
        <div class="mb-3">
          <input
            type="text"
            id="searchInput"
            class="form-control shadow-sm"
            placeholder="Masukkan Nama Penitip atau Email Penitip..."
          />
        </div>

        <div id="notFoundMessage" class="alert alert-warning d-none">
        Transaksi tidak ditemukan.
      </div>

        <!-- Tabel Data -->
        <div class="card shadow-sm">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-bordered mb-0" id="dataTable">
                <thead class="table-light text-center">
                  <tr>
                    <th>ID Penitipan</th>
                    <th>Tanggal Penitipan</th>
                    <th>Nama Penitip</th>
                    <th>Email Penitip</th>
                    <th>Action</th>
                  </tr>
                </thead>            
                <tbody class="text-center align-middle" id="penitipanTable">
                 @forelse ($penitipanList as $penitipan)
                    <tr>
                    <td>{{ $penitipan->ID_PENITIPAN }}</td>
                    <td>{{ $penitipan->TANGGAL_PENITIPAN }}</td>
                    <td>{{ $penitipan->penitip->NAMA_PENITIP ?? '-' }}</td>
                    <td>{{ $penitipan->penitip->EMAIL_PENITIP ?? '-' }}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal{{ $penitipan->ID_PENITIPAN }}">Edit</button>
                        <a href="{{ route('penitipan.transaksi', $penitipan->ID_PENITIPAN) }}" class="btn btn-success btn-sm">Barang</a>
                    </td>
                    </tr>
                      <!-- Modal -->
<div class="modal fade" id="createPenitipanModal" tabindex="-1" aria-labelledby="createPenitipanLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="{{ route('penitipan.store') }}" method="POST">
        @csrf
        <div class="modal-header">
          <h5 class="modal-title" id="createPenitipanLabel">Tambah Data Penitipan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="ID_PENITIP" class="form-label">ID Penitip</label>
            <input type="text" name="ID_PENITIP" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="ID_PEGAWAI" class="form-label">ID Pegawai</label>
            <input type="text" name="ID_PEGAWAI" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="TANGGAL_PENITIPAN" class="form-label">Tanggal Penitipan</label>
            <input type="date" name="TANGGAL_PENITIPAN" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="TANGGAL_BERAKHIR" class="form-label">Tanggal Berakhir</label>
            <input type="date" name="TANGGAL_BERAKHIR" class="form-control">
          </div>
          <div class="mb-3">
            <label for="STATUS_PERPANJANGAN" class="form-label">Status Perpanjangan</label>
            <select name="STATUS_AMBIL_KEMBALI" class="form-select">
              <option value="">Pilih...</option>
              <option value="1">Sudah</option>
              <option value="0">Belum</option>
            </select>
          </div>
          <div class="mb-3">
            <label for="BATAS_AMBIL" class="form-label">Batas Ambil</label>
            <input type="date" name="BATAS_AMBIL" class="form-control">
          </div>
          <div class="mb-3">
            <label for="STATUS_AMBIL_KEMBALI" class="form-label">Status Ambil Kembali</label>
          <select name="STATUS_AMBIL_KEMBALI" class="form-select">
            <option value="">Pilih...</option>
            <option value="1">Sudah</option>
            <option value="0">Belum</option>
          </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>


<!-- Modal Edit: Harus diletakkan di dalam loop -->
<div class="modal fade" id="editModal{{ $penitipan->ID_PENITIPAN }}" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="{{ route('penitipan.edit', $penitipan->ID_PENITIPAN) }}" method="POST">
      @csrf
      @method('POST')
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Data Penitipan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label>Nama Penitip</label>
            <input type="text" name="NAMA_PENITIP" class="form-control" value="{{ $penitipan->penitip->NAMA_PENITIP }}">
          </div>
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="EMAIL_PENITIP" class="form-control" value="{{ $penitipan->penitip->EMAIL_PENITIP }}">
          </div>
          <div class="mb-3">
            <label>Tanggal Penitipan</label>
            <input type="date" name="TANGGAL_PENITIPAN" class="form-control" value="{{ \Carbon\Carbon::parse($penitipan->TANGGAL_PENITIPAN)->format('Y-m-d') }}">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </div>
      </div>
    </form>
  </div>
</div>

                  @empty
                  <tr>
                    <td colspan="5" class="text-muted">Tidak ada data penitipan.</td>
                  </tr>
                  @endforelse
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
<div class="modal fade" id="createPenitipanModal" tabindex="-1" aria-labelledby="createPenitipanLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="{{ route('penitipan.store') }}" method="POST">
        @csrf
        <div class="modal-header">
          <h5 class="modal-title" id="createPenitipanLabel">Tambah Data Penitipan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="ID_PENITIP" class="form-label">ID Penitip</label>
            <input type="text" name="ID_PENITIP" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="ID_PEGAWAI" class="form-label">ID Pegawai</label>
            <input type="text" name="ID_PEGAWAI" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="TANGGAL_PENITIPAN" class="form-label">Tanggal Penitipan</label>
            <input type="date" name="TANGGAL_PENITIPAN" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="TANGGAL_BERAKHIR" class="form-label">Tanggal Berakhir</label>
            <input type="date" name="TANGGAL_BERAKHIR" class="form-control">
          </div>
          <div class="mb-3">
            <label for="STATUS_PERPANJANGAN" class="form-label">Status Perpanjangan</label>
            <select name="STATUS_AMBIL_KEMBALI" class="form-select">
              <option value="">Pilih...</option>
              <option value="1">Sudah</option>
              <option value="0">Belum</option>
            </select>
          </div>
          <div class="mb-3">
            <label for="BATAS_AMBIL" class="form-label">Batas Ambil</label>
            <input type="date" name="BATAS_AMBIL" class="form-control">
          </div>
          <div class="mb-3">
            <label for="STATUS_AMBIL_KEMBALI" class="form-label">Status Ambil Kembali</label>
          <select name="STATUS_AMBIL_KEMBALI" class="form-select">
            <option value="">Pilih...</option>
            <option value="1">Sudah</option>
            <option value="0">Belum</option>
          </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>


<!-- Modal Edit -->
<div class="modal fade" id="editModal{{ $penitipan->ID_PENITIPAN}}" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="{{ route('penitipan.edit', $penitipan->ID_PENITIPAN) }}" method="POST">
      @csrf
      @method('POST')
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Data Penitipan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label>Nama Penitip</label>
            <input type="text" name="NAMA_PENITIP" class="form-control" value="{{ $penitipan->penitip->NAMA_PENITIP }}">
          </div>
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="EMAIL_PENITIP" class="form-control" value="{{ $penitipan->penitip->EMAIL_PENITIP }}">
          </div>
          <div class="mb-3">
            <label>Tanggal Penitipan</label>
<input type="date" name="TANGGAL_PENITIPAN" class="form-control" value="{{ \Carbon\Carbon::parse($penitipan->TANGGAL_PENITIPAN)->format('Y-m-d') }}">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </div>
      </div>
    </form>
  </div>
</div>

  <!-- Optional JS untuk pencarian sederhana -->
   <!-- Bootstrap Bundle with Popper (WAJIB untuk Modal bekerja) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
  document.getElementById('searchInput').addEventListener('keyup', function () {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#penitipanTable tr');
    const notFoundMessage = document.getElementById("notFoundMessage");
    const tableElement = document.getElementById("dataTable");
    let found = false;

    rows.forEach((row) => {
      const nama = row.children[2]?.textContent.toLowerCase() || '';
      const email = row.children[3]?.textContent.toLowerCase() || '';
      const isMatch = nama.includes(filter) || email.includes(filter);
      row.style.display = isMatch ? '' : 'none';
      if (isMatch) found = true;
    });

    notFoundMessage.classList.toggle("d-none", found);
    tableElement.style.display = found ? "table" : "none";
  });
</script>



  <!-- Bootstrap JS Bundle (includes Popper) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
