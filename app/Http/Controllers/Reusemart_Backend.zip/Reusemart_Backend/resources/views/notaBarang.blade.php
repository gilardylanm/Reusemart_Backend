    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Nota Penitipan</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                font-family: Arial, sans-serif;
            }
            .nota-container {
                border: 1px solid black;
                padding: 20px;
                width: 350px;
                margin: auto;
            }
            .text-small {
                font-size: 14px;
            }
            .fw-medium {
                font-weight: 500;
            }
            @media print {
                .no-print {
                    display: none;
                }
            }
        </style>
    </head>
    <body class="p-4">

        <div class="nota-container">
            <div class="text-center fw-bold">ReUse Mart</div>
            <div class="text-center text-small">Jl. Green Eco Park No. 456 Yogyakarta</div>

            <div class="mt-3 text-small">
                <p>No Nota: {{ $barangList[0]->NO_NOTA }}</p>
                <div>Tanggal penitipan : {{ \Carbon\Carbon::parse($barangList[0]->TANGGAL_PENITIPAN)->format('d/m/Y H:i:s') }}</div>
                <div>Masa penitipan sampai: {{ \Carbon\Carbon::parse($barangList[0]->TANGGAL_PENITIPAN)->addDays(30)->format('d/m/Y') }}</div>

            </div>

            <div class="mt-3 text-small">
                <strong>Penitip :</strong> {{ $barangList[0]->ID_PENITIP }} / {{ $barangList[0]->NAMA_PENITIP }}<br>
                {{ $barangList[0]->ALAMAT_PENITIP }}<br>
                Delivery: Kurir ReUseMart ({{ $barangList[0]->NAMA_KURIR ?? '-' }})
            </div>

            <div class="mt-3 text-small">
                @foreach ($barangList as $barang)
                    <div class="d-flex justify-content-between">
                        <div>{{ $barang->NAMA_BARANG }}</div>
                        <div>Rp {{ number_format($barang->HARGA_BARANG, 0, ',', '.') }}</div>
                    </div>
                    @if (!empty($barang->GARANSI))
                        <div>Garansi {{ $barang->GARANSI }}</div>
                    @endif
                    @if (!empty($barang->BERAT))
                        <div>Berat barang: {{ $barang->BERAT }} kg</div>
                    @endif
                @endforeach
            </div>

    <div class="mt-4 text-small">
        Diterima dan QC oleh: {{ $barangList[0]->NAMA_PEGAWAI_GUDANG ?? '-' }}
    </div>
        </div>

        <div class="text-center mt-3">
            <button onclick="window.print()" class="btn btn-primary no-print">Print Nota</button>
        </div>

    </body>
    </html>
