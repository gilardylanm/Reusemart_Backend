 <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <title>Request Donasi - ReuseMart</title>
  <!-- Font Awesome for icons -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
  />
  <!-- Bootstrap CSS -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body {
      background-color: #0d5c4f;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 30px;
      background-color: white;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .logo {
      display: flex;
      align-items: center;
    }

    .logo img {
      height: 40px;
    }

    .nav-links {
      display: flex;
      gap: 30px;
    }

    .nav-links a {
      text-decoration: none;
      color: black;
      font-size: 18px;
    }

    .container-fluid {
      padding: 40px;
    }

    .main-content {
      background-color: white;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .page-title {
      color: #18594a;
      margin-bottom: 30px;
      font-weight: bold;
    }

    .btn-request {
      background-color: #18594a;
      color: white;
      border: none;
      padding: 8px 20px;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
      margin-bottom: 20px;
      transition: background-color 0.3s ease;
    }

    .btn-request:hover {
      background-color: orange;
      color: black;
    }

    .search-container {
      margin-bottom: 20px;
    }

    .search-box {
      position: relative;
      max-width: 400px;
    }

    .search-input {
      width: 100%;
      padding: 8px 40px 8px 15px;
      border-radius: 20px;
      border: 1px solid #ccc;
    }

    .search-icon {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #777;
    }

    .data-table {
      width: 100%;
      border-collapse: collapse;
    }

    .table-header {
      background-color: #18594a;
      color: white;
    }

    .badge-menunggu {
      background-color: #ffc107;
      color: #000;
    }

    .badge-disetujui {
      background-color: #28a745;
    }

    .no-data-message {
      text-align: center;
      padding: 20px;
      font-style: italic;
      color: #777;
      display: none;
    }

    .badge {
  display: inline-block;
  padding: 0.25em 0.6em;
  font-size: 75%;
  font-weight: 700;
  line-height: 1;
  color: #fff;
  text-align: center;
  white-space: nowrap;
  vertical-align: baseline;
  border-radius: 0.375rem;
}

    .badge-success {
    background-color: #28a745;
    }

    .badge-danger {
    background-color: #dc3545;
    }

    .badge-primary {
    background-color: #007bff;
    }

    .badge-secondary {
    background-color: #6c757d;
    }

  </style>
</head>
<body style="background-color: #0d5c4f;">
  <div class="container mt-3">
    <div class="card">
      <div class="card-body">
        <!-- Navbar -->
        <div class="navbar">
          <div class="logo">
            <img src="{{ asset('img/Logo ReuseMart.jpg') }}" alt="ReuseMart Logo" />
          </div>
          <div class="nav-links">       
            <a href="beranda.php">Beranda</a>
            <a href="/organisasi">Request Donasi</a>
            <a href="profilAkun.php">Profil Akun</a>
          </div>
        </div>

        <h2 class="mb-3 fw-bold">Data Penitipan</h2>

        <!-- Input Pencarian -->
        <div class="mb-3">
          <input
            type="text"
            id="searchInput"
            class="form-control shadow-sm"
            placeholder="Masukkan Nama Barang..."
          />
        </div>

        <!-- Tabel Data -->
        <div class="card shadow-sm">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-bordered mb-0">
                <thead class="table-light text-center">
  <tr>
    <th>Nama Penitip</th>
    <th>Nama Barang</th>
    <th>Tanggal Penitipan</th>
    <th>Tanggal Berakhir</th>
    <th>Status Barang</th>
    <th>Status Perpanjangan</th>
    <th>Action</th>
  </tr>
</thead>
<tbody class="text-center align-middle" id="penitipTable">
  @forelse ($riwayatPenitipan as $penitip)
  <tr>
    <td>{{ $penitip->NAMA_PENITIP }}</td> <!-- Nama Penitip -->
    <td>{{ $penitip->NAMA_BARANG }}</td> <!-- Nama Barang -->
    <td>{{ \Carbon\Carbon::parse($penitip->TANGGAL_PENITIPAN)->format('d-m-Y') }}</td> <!-- Tanggal Penitipan -->
    <td>{{ \Carbon\Carbon::parse($penitip->TANGGAL_BERAKHIR)->format('d-m-Y') }}</td> <!-- Tanggal Berakhir -->
<td>
  @if ($penitip->STATUS_BARANG == 'Tersedia')
    <span class="badge badge-success">Tersedia</span>
  @elseif ($penitip->STATUS_BARANG == 'Terjual')
    <span class="badge badge-danger">Terjual</span>
  @else ($penitip->STATUS_BARANG == 'Barang Donasi')
    <span class="badge badge-primary">Donasi</span>
  @endif
</td>
    <td>
        @if($penitip->STATUS_PERPANJANGAN == 0)
        <span class="badge badge-menunggu">Menunggu</span>
        @elseif($penitip->STATUS_PERPANJANGAN == 1)
        <span class="badge badge-disetujui">Disetujui</span>
        @endif
    </td>
    <td>
      <form action="{{ route('penitipan.perpanjang', $penitip->ID_PENITIPAN) }}" method="POST" onsubmit="return confirm('Perpanjang tanggal berakhir +30 hari?')">
    @csrf
    <button type="submit" class="btn btn-success btn-sm">Perpanjangan</button>
</form>
    </td>
  </tr>
  @empty
  <tr>
    <td colspan="6" class="text-muted">Tidak ada data penitip.</td>
  </tr>
  @endforelse
</tbody>


              </table>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Optional JS untuk pencarian sederhana -->
  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    document.getElementById('searchInput').addEventListener('keyup', function () {
      let filter = this.value.toLowerCase();
      let rows = document.querySelectorAll('#penitipTable tr');

      rows.forEach((row) => {
        const nama = row.children[1]?.textContent.toLowerCase() || '';
        const email = row.children[2]?.textContent.toLowerCase() || '';
        row.style.display =
          nama.includes(filter) || email.includes(filter) ? '' : 'none';
      });
    });
  </script>
</body>
</html>
