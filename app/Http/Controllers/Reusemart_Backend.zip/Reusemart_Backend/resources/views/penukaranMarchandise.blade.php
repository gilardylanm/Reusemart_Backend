<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar Merchandise Penukaran Poin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }
        .header-section {
            background-color: #2d7c2d;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
        }
        .status-available {
            background-color: #2ecc71;
            color: white;
        }
        .status-out {
            background-color: #e74c3c;
            color: white;
        }
        .status-limited {
            background-color: #f39c12;
            color: white;
        }
        .action-btn {
            width: 30px;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        .search-box {
            position: relative;
            max-width: 300px;
        }
        .search-box i {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <div class="header-section">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h2 class="mb-1"><i class="fas fa-gift me-2"></i>Daftar Merchandise Penukaran Poin</h2>
                <p class="mb-0">Total merchandise tersedia: 45 item</p>
            </div>
            <div>
                <button class="btn btn-light me-2" data-bs-toggle="modal" data-bs-target="#filterModal">
                    <i class="fas fa-filter me-1"></i> Filter
                </button>
                <button class="btn btn-light me-2">
                    <i class="fas fa-file-export me-1"></i> Export
                </button>
                <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#createMerchandiseModal">
                    <i class="fas fa-plus me-1"></i> Tambah Baru
                </button>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="search-box">
                        <input type="text" class="form-control" placeholder="Cari merchandise...">
                        <i class="fas fa-search"></i>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <div class="btn-group">
                        <button class="btn btn-outline-secondary active">Semua</button>
                        <button class="btn btn-outline-secondary">Tersedia</button>
                        <button class="btn btn-outline-secondary">Habis</button>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID Merchandise</th>
                            <th>Nama Merchandise</th>
                            <th class="text-center">Stok</th>
                            <th class="text-center">Poin Diperlukan</th>
                            <th>Nama Penukar</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>MCH-001</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="https://via.placeholder.com/40" alt="Merchandise" class="rounded me-2" width="40" height="40">
                                    <span>Voucher Belanja Rp100.000</span>
                                </div>
                            </td>
                            <td class="text-center">45</td>
                            <td class="text-center">1.000</td>
                            <td>-</td>
                            <td class="text-center"><span class="status-badge status-available">Tersedia</span></td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-outline-primary action-btn me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger action-btn" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>MCH-002</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="https://via.placeholder.com/40" alt="Merchandise" class="rounded me-2" width="40" height="40">
                                    <span>Tumbler Exclusive</span>
                                </div>
                            </td>
                            <td class="text-center">12</td>
                            <td class="text-center">2.500</td>
                            <td>-</td>
                            <td class="text-center"><span class="status-badge status-limited">Terbatas</span></td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-outline-primary action-btn me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger action-btn" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>MCH-003</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="https://via.placeholder.com/40" alt="Merchandise" class="rounded me-2" width="40" height="40">
                                    <span>Power Bank 10.000mAh</span>
                                </div>
                            </td>
                            <td class="text-center">0</td>
                            <td class="text-center">5.000</td>
                            <td>Budi Santoso</td>
                            <td class="text-center"><span class="status-badge status-out">Habis</span></td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-outline-primary action-btn me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger action-btn" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <!-- Data lainnya -->
                    </tbody>
                </table>
            </div>

            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <li class="page-item disabled">
                        <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                    </li>
                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Modal Filter -->
<div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Filter Merchandise</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Status Stok</label>
                    <select class="form-select">
                        <option selected>Semua Status</option>
                        <option value="1">Tersedia</option>
                        <option value="2">Terbatas</option>
                        <option value="3">Habis</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Rentang Poin</label>
                    <div class="row">
                        <div class="col">
                            <input type="number" class="form-control" placeholder="Minimum">
                        </div>
                        <div class="col">
                            <input type="number" class="form-control" placeholder="Maksimum">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Kategori</label>
                    <select class="form-select">
                        <option selected>Semua Kategori</option>
                        <option value="1">Voucher</option>
                        <option value="2">Elektronik</option>
                        <option value="3">Fashion</option>
                        <option value="4">Lainnya</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Reset</button>
                <button type="button" class="btn btn-primary">Terapkan Filter</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Merchandise -->
<div class="modal fade" id="createMerchandiseModal" tabindex="-1" aria-labelledby="createMerchandiseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form>
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Merchandise Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Nama Merchandise</label>
                                <input type="text" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Kategori</label>
                                <select class="form-select" required>
                                    <option value="">Pilih Kategori</option>
                                    <option value="1">Voucher</option>
                                    <option value="2">Elektronik</option>
                                    <option value="3">Fashion</option>
                                    <option value="4">Lainnya</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Poin Diperlukan</label>
                                <input type="number" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Stok Awal</label>
                                <input type="number" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Gambar Merchandise</label>
                                <input type="file" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Deskripsi</label>
                                <textarea class="form-control" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>