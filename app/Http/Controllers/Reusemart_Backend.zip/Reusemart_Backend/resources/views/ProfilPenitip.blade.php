<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Penitip - ReuseMart</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            background-color: #0D5C4F;
        }
        
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 30px;
            background-color: white;
        }
        
        .logo {
            display: flex;
            align-items: center;
        }
        
        .logo img {
            height: 40px;
        }
        
        .nav-links {
            display: flex;
            gap: 30px;
        }
        
        .nav-links a {
            text-decoration: none;
            color: black;
            font-size: 18px;
        }
        
        .container {
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 40px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .profile-card {
            background-color: white;
            border-radius: 10px;
            padding: 30px;
            width: 100%;
            max-width: 600px;
        }
        
        .profile-title {
            color: #164B45;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .profile-field {
            margin-bottom: 20px;
        }
        
        .field-label {
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .field-input {
            display: flex;
            align-items: center;
            background: linear-gradient(135deg, #0D5C4F, #1a9e85);
            width: 80%;
            padding: 12px 15px;
            border-radius: 5px;
            color: white;
        }
        
        .field-input i {
            margin-right: 10px;
        }
        
        .rating-field {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .rating-stars {
            color: #ebb734;
            font-size: 18px;
        }
        
        .rating-value {
            font-size: 16px;
            font-weight: bold;
            color: #164B45;
        }
        
        .right-column {
            display: flex;
            flex-direction: column;
            gap: 20px;
            width: 100%;
            max-width: 300px;
        }
        
        .balance-card, .points-card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .card-title {
            color: #164B45;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        
        .balance-amount {
            background-color: #D6ED17;
            color: black;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            font-size: 22px;
        }
        
        .points-amount {
            background-color: #30C67C;
            color: white;
            padding: 20px;
            border-radius: 5px;
            font-weight: bold;
            font-size: 40px;
            width: 60%;
            text-align: center;
            margin-bottom: 10px;
        }
        
        .points-label {
            color: #0D5C4F;
            font-size: 18px;
            margin-bottom: 15px;
        }
        
        .points-info {
            text-align: center;
            margin-bottom: 15px;
            font-size: 14px;
        }
        
        .exchange-btn {
            background-color: #ebb734;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">
            <img src="img/Logo ReuseMart.jpg" alt="ReuseMart Logo">
        </div>
        <div class="nav-links">
            <a href="beranda.php">Beranda</a>
            <a href="history.php">History</a>
            <a href="profilAkun.php">Profil Akun</a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="container">
        <!-- Profile Information -->
        <div class="profile-card">
            <h2 class="profile-title">Profil Penitip</h2>
            
            <div class="profile-field">
                <div class="field-label">Nama Pembeli</div>
                <div class="field-input">
                    <i class="fas fa-user"></i>
                    <span>Jhon Deep</span>
                </div>
            </div>
            
            <div class="profile-field">
                <div class="field-label">Nomor Telepon</div>
                <div class="field-input">
                    <i class="fas fa-phone"></i>
                    <span>081343336270</span>
                </div>
            </div>
            
            <div class="profile-field">
                <div class="field-label">Email</div>
                <div class="field-input">
                    <i class="fas fa-envelope"></i>
                    <span>jhondeep@gmail.com</span>
                </div>
            </div>
            
<div class="profile-field">
    <div class="field-label">Rating</div>
    <div class="rating-field">
        <div class="rating-stars">
            @php
                $fullStars = floor($averageRating);
                $halfStar = ($averageRating - $fullStars) >= 0.5;
            @endphp

            @for ($i = 0; $i < $fullStars; $i++)
                <i class="fas fa-star"></i>
            @endfor

            @if ($halfStar)
                <i class="fas fa-star-half-alt"></i>
            @endif

            @for ($i = 0; $i < 5 - $fullStars - ($halfStar ? 1 : 0); $i++)
                <i class="far fa-star"></i>
            @endfor
        </div>
        <div class="rating-value">{{ $averageRating }}</div>
    </div>
</div>

        </div>
        
        <!-- Right Column - Balance and Points -->
        <div class="right-column">
            <!-- Balance Card -->
            <div class="balance-card">
                <h3 class="card-title">Saldo Anda</h3>
                <div class="balance-amount">Rp158.000</div>
            </div>
            
            <!-- Points Card -->
            <div class="points-card">
                <h3 class="card-title">Poin Reward</h3>
                <div class="points-amount">50</div>
                <div class="points-label">Points</div>
                <div class="points-info">Tukar Poin Anda Dengan Merchandise</div>
                <button class="exchange-btn">Tukar Poin</button>
            </div>
        </div>
    </div>
</body>
</html>