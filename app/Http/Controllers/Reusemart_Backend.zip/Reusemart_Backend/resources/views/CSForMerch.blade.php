<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ReuseMart - CS (Kelola Penitip)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        }

        /* Header styles (same as previous file) */
        header {
            background-color: white;
            padding: 10px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .logo img {
            height: 40px;
        }

        nav {
            display: flex;
            gap: 30px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            font-size: 18px;
        }

        .sidebar {
            background-color: #18594a;
            color: white;
            min-height: calc(100vh - 56px);
            padding-top: 20px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            padding: 15px 20px;
        }

        .sidebar-menu li:hover {
            background-color: #124035;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .sidebar-menu i {
            margin-right: 10px;
            font-size: 20px;
        }

        .main-content {
            padding: 20px;
        }

        .btn-add {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            position: absolute;
            top: 80px;
            right: 30px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .btn-add:hover {
            background-color: black;
            color: white;
        }

        .search-container {
            margin-bottom: 20px;
            display: flex;
            justify-content: left;
        }

        .search-box {
            width: 400px;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 8px 40px 8px 10px;
            border-radius: 20px;
            border: 1px solid #ccc;
        }

        .search-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
        }

        .data-table {
            background-color: white;
            border-radius: 5px;
            overflow: hidden;
        }

        .table-header {
            background-color: #18594a;
            color: white;
            font-weight: 500;
        }

        .table td {
            vertical-align: middle;
        }

        .no-data-message {
            text-align: center;
            padding: 20px;
            font-style: italic;
            color: #777;
        }

        .ktp-thumbnail {
            max-width: 100px;
            max-height: 100px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <!-- Header with navigation -->
    <header>
        <div class="logo">
            <img src="/img/Logo ReuseMart.jpg" alt="ReuseMart Logo">
        </div>
        <nav>
            <a href="#">Beranda</a>
            <a href="#">Kelola Penitip</a>
            <a href="#">Profil Akun</a>
        </nav>
    </header>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <ul class="sidebar-menu">
                    <li class="active">
                        <a href="/csPenitip" class="cs-penitip">
                            <i class="fas fa-users"></i>
                            Data Penitip
                        </a>
                    </li>
                    <li>
                        <a href="/CSForPembayaran" class="cs-pembayaran">
                            <i class="fas fa-money-check"></i>
                            Verifikasi Pembayaran
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('penukaran.index') }}" class="cs-merchandise">
                            <i class="fas fa-gift"></i>
                            Kelola Merchandise
                        </a>
                    </li>
                    <li>
                        <a href="/CSForReset" class="CS-reset">
                            <i class="fas fa-key"></i>
                            Reset Password
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main content -->
            <div class="col-md-10 main-content">

                <div class="data-table mt-3">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nama Merchandise</th>
                                <th>Nama Penukar</th>
                                <th>Tanggal Klaim</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($merchList as $penitip)
                                <tr>
                                    <td>{{ $penitip->merchandise->NAMA_MERCHANDISE }}</td>
                                    <td>{{ $penitip->pembeli->NAMA_PEMBELI }}</td>
                                    <td>{{ \Carbon\Carbon::parse($penitip->TANGGAL_KLAIM)->format('d-m-Y') }}</td>
                                    <td>
                                        <button class="btn btn-sm btn-warning btn-edit" data-id="{{ $penitip->ID_PENUKARAN }}" data-tanggal="{{ $penitip->TANGGAL_KLAIM }}">
                                            <i class="fas fa-edit"></i> Ubah
                                        </button>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-center">Belum ada data penitip.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ubah Tanggal Klaim -->
    <div class="modal fade" id="editTanggalModal" tabindex="-1" aria-labelledby="editTanggalModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="/ubah-tanggal-klaim"> <!-- Ganti dengan route Laravel yang sesuai -->
            @csrf
            <input type="hidden" name="id" id="edit-id">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ubah Tanggal Klaim</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                </div>
                <div class="modal-body">
                    <label for="tanggal">Tanggal Klaim Baru:</label>
                    <input type="date" class="form-control" name="tanggal" id="edit-tanggal" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </div>
        </form>
    </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
            // Array untuk menyimpan data penitip
        document.addEventListener('DOMContentLoaded', function () {
            const editButtons = document.querySelectorAll('.btn-edit');
            const editModal = new bootstrap.Modal(document.getElementById('editTanggalModal'));

            editButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const id = this.getAttribute('data-id');
                    const tanggal = this.getAttribute('data-tanggal');

                    document.getElementById('edit-id').value = id;
                    document.getElementById('edit-tanggal').value = tanggal;

                    editModal.show();
                });
            });
        });
    </script>
    
</body>

</html>