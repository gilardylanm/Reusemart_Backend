<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ReUseMart</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        /* Header styles */
        header {
            background-color: white;
            padding: 10px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .nav-links {
            display: flex;
            gap: 30px;
        }
        
        .nav-links a {
            text-decoration: none;
            color: black;
            font-size: 18px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .logo img {
            height: 40px;
        }

        .category-btn {
            white-space: nowrap;
        }

        .category-scroll {
            overflow-x: auto;
            white-space: nowrap;
            padding-bottom: 15px;
        }

        .product-card img {
            height: 220px;
            object-fit: cover;
        }

        .product-section {
            background-color: #1e5631;
            padding: 5rem 0;
        }

        .product-card a {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Header with navigation -->
    <header>
        <div class="logo">
            <img src="/img/Logo ReuseMart.jpg" alt="ReuseMart Logo">
        </div>
        <div class="nav-links">
            <a href="/halamanPembeli">Beranda</a>
            <a href="/historyPembelian">History Pembelian</a>
            <a href="/profilPembeli">Profil Akun</a>
        </div>
    </header>

    <!-- product Search -->
    <div class="product-section text-white text-center">
        <div class="container">
            <div class="mb-4">
                <input type="text" class="form-control form-control-lg" id="searchInput" placeholder="Cari produk atau kategori..." aria-label="Cari Produk">
            </div>
            <h1 class="display-5 fw-bold">
                Search for anything<br>on ReuseMart
            </h1>
        </div>
    </div>

    <!-- Categories -->
    <div class="container mt-4">
        <div class="category-scroll">
            <div class="d-inline-flex gap-3">
                <button data-category="all" class="category-btn btn btn-light border shadow-sm px-4 py-3 fw-semibold active">📦 Semua Kategori</button>
                <button data-category="gadget" class="category-btn btn btn-white border shadow-sm px-4 py-3">📱 Elektronik dan Gadget</button>
                <button data-category="pakaian" class="category-btn btn btn-white border shadow-sm px-4 py-3">👕 Pakaian dan Aksesori</button>
                <button data-category="perabot" class="category-btn btn btn-white border shadow-sm px-4 py-3">🪑 Perabotan Rumah Tangga</button>
                <button data-category="buku" class="category-btn btn btn-white border shadow-sm px-4 py-3">📚 Buku & Alat Tulis</button>
                <button data-category="hobi" class="category-btn btn btn-white border shadow-sm px-4 py-3">🎮 Hobi & Koleksi</button>
                <button data-category="bayi" class="category-btn btn btn-white border shadow-sm px-4 py-3">🍼 Perlengkapan Bayi</button>
                <button data-category="otomotif" class="category-btn btn btn-white border shadow-sm px-4 py-3">🚗 Otomotif</button>
                <button data-category="taman" class="category-btn btn btn-white border shadow-sm px-4 py-3">🌿 Taman & Outdoor</button>
                <button data-category="kantor" class="category-btn btn btn-white border shadow-sm px-4 py-3">🏢 Kantor & Industri</button>
                <button data-category="kosmetik" class="category-btn btn btn-white border shadow-sm px-4 py-3">💄 Kosmetik</button>
            </div>
        </div>
    </div>

    <!-- Product Section -->
    <div class="container mt-5">
        <h2 class="fs-4 fw-semibold mb-4">Produk</h2>
        <div class="row row-cols-2 row-cols-md-4 g-4">
            <!-- Produk per kategori -->
            <div class="col product-card" data-category="gadget">
                <a href="/detailProduk">
                    <div class="card h-100 shadow">
                        <img src="img/iphone162.jpg" alt="Iphone 162" class="card-img-top rounded-top" alt="IPhone 16 Pro Max">
                        <div class="card-body">
                            <h5 class="card-title fs-6 fw-semibold">IPhone 16 Pro Max</h5>
                            <p class="card-text fw-bold fs-5 mb-0">Rp16.000.000</p>
                        </div>
                    </div>
                </a>
            </div>
                    <div class="col product-card" data-category="pakaian">
            <div class="card h-100 shadow">
                <img src="img/jaket denim.jpg" alt="Jaket Denim" class="card-img-top rounded-top" alt="Pakaian">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Jaket Denim Pria</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp250.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="perabot">
            <div class="card h-100 shadow">
                <img src="img/kursi.jpg" alt="kursi kayu" class="card-img-top rounded-top" alt="Perabot">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Kursi Kayu Vintage</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp400.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="buku">
            <div class="card h-100 shadow">
                <img src="img/fisika.jpg" alt="Fisika" class="card-img-top rounded-top" alt="Buku">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Buku Fisika SMA</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp80.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="hobi">
            <div class="card h-100 shadow">
                <img src="img/rcar.jpg" alt="Rcar" class="card-img-top rounded-top" alt="Hobi">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Remote Control Car</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp350.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="bayi">
            <div class="card h-100 shadow">
                <img src="img/stoler.jpg" alt="Stoler" class="card-img-top rounded-top" alt="Bayi">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Stroller Bayi Lipat</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp1.200.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="otomotif">
            <div class="card h-100 shadow">
                <img src="img/sarungtangan.jpg" alt="SarungTangan" class="card-img-top rounded-top" alt="Otomotif">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Sarung Tangan</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp150.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="taman">
            <div class="card h-100 shadow">
                <img src="img/setalatkebun.jpg" alt="setalatkebun" class="card-img-top rounded-top" alt="Taman">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Set Alat Kebun Mini</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp120.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="kantor">
            <div class="card h-100 shadow">
                <img src="img/printer.jpg" alt="Printer" class="card-img-top rounded-top" alt="Kantor">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Printer Kantor</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp1.500.000</p>
                </div>
            </div>
        </div>
        <div class="col product-card" data-category="kosmetik">
            <div class="card h-100 shadow">
                <img src="img/parfum.jpg" alt="Parfum" class="card-img-top rounded-top" alt="Kosmetik">
                <div class="card-body">
                    <h5 class="card-title fs-6 fw-semibold">Parfum Wanita</h5>
                    <p class="card-text fw-bold fs-5 mb-0">Rp70.000</p>
                </div>
            </div>
        </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white mt-5 py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-4 text-md-start">
                    <img src="/img/Logo ReuseMart.jpg" alt="ReUseMart Logo" style="height: 80px; margin-left: -50px;">
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-4 text-end">
                            <p class="mb-0"><strong>About us</strong><br>our story</p>
                        </div>
                        <div class="col-md-4 text-end">
                            <p class="mb-0"><strong>Address</strong><br>Jl. Green Eco Park No. 456<br>Yogyakarta, 12345<br>Indonesia</p>
                        </div>
                        <div class="col-md-4 text-end">
                            <p class="mb-0"><strong>Follow us</strong></p>
                            <div class="mt-2">
                                <a href="#" class="text-decoration-none text-dark d-block mb-2">
                                    <i class="bi bi-facebook fs-5 me-2"></i>Facebook
                                </a>
                                <a href="#" class="text-decoration-none text-dark d-block mb-2">
                                    <i class="bi bi-instagram fs-5 me-2"></i>Instagram
                                </a>
                                <a href="#" class="text-decoration-none text-dark d-block mb-2">
                                    <i class="bi bi-linkedin fs-5 me-2"></i>LinkedIn
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-3 text-secondary small">
                <p class="mb-0">© 2025 ReUseMart. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Script kategori -->
    <script>
        const categoryButtons = document.querySelectorAll('.category-btn');
        const productCards = document.querySelectorAll('.product-card');

        categoryButtons.forEach(button => {
            button.addEventListener('click', () => {
                const selected = button.getAttribute('data-category');

                productCards.forEach(card => {
                    if (selected === 'all') {
                        card.style.display = '';
                    } else {
                        card.style.display = (card.getAttribute('data-category') === selected) ? '' : 'none';
                    }
                });

                // Update active state for buttons
                categoryButtons.forEach(btn => {
                    btn.classList.remove('active', 'btn-light');
                    btn.classList.add('btn-white');
                });
                button.classList.remove('btn-white');
                button.classList.add('active', 'btn-light');
            });
        });

        const searchInput = document.getElementById('searchInput');

        searchInput.addEventListener('input', function() {
            const query = searchInput.value.toLowerCase();

            productCards.forEach(card => {
                const productTitle = card.querySelector('.card-title').textContent.toLowerCase();
                if (productTitle.includes(query)) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    </script>

</body>
</html>
